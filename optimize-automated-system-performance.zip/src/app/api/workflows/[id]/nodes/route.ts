import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { workflowNodes } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { label, nodeType, actionType, config } = body;

    if (!label || !nodeType) {
      return NextResponse.json({ error: "Label and Node Type required" }, { status: 400 });
    }

    // get existing nodes to count step order
    const existing = await db.select().from(workflowNodes).where(eq(workflowNodes.workflowId, id));
    const nextOrder = existing.length + 1;
    const nodeId = `node-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 5)}`;

    await db.insert(workflowNodes).values({
      id: nodeId,
      workflowId: id,
      label,
      nodeType,
      actionType: actionType || "Automated Task",
      config: JSON.stringify(config || { enabled: true, autoRecover: true }),
      stepOrder: nextOrder
    });

    return NextResponse.json({ success: true, nodeId, message: "Node step added successfully to workflow" });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { searchParams } = new URL(req.url);
    const nodeId = searchParams.get("nodeId");
    if (!nodeId) {
      return NextResponse.json({ error: "nodeId param required" }, { status: 400 });
    }
    await db.delete(workflowNodes).where(eq(workflowNodes.id, nodeId));
    return NextResponse.json({ success: true, message: "Node step removed" });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
