import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "NexusAutomate AI — Autonomous Workflow & Bug Deflector System",
  description: "Enterprise multi-step automated workflows, self-healing system bug watchdogs, and sub-second execution engines powered by Next.js and PostgreSQL via Drizzle ORM.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
