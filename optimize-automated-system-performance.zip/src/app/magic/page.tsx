"use client";
import SEO1000Page from "@/app/seo1000/page";
export default function MagicAliasPage() {
  return <SEO1000Page />;
}
