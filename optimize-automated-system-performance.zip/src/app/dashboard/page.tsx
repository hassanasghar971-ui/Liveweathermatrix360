"use client";
import HomePage from "@/app/page";
export default function DashboardAliasPage() {
  return <HomePage />;
}
