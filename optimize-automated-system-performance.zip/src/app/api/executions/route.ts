import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { executions } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const workflowId = searchParams.get("workflowId");

    let query = db.select().from(executions).orderBy(desc(executions.executedAt));
    if (workflowId && workflowId !== "all") {
      query = db.select().from(executions).where(eq(executions.workflowId, workflowId)).orderBy(desc(executions.executedAt)) as any;
    }

    const res = await query;
    const enriched = res.slice(0, 100).map(item => ({
      ...item,
      logs: (() => { try { return JSON.parse(item.logs); } catch { return []; } })(),
      outputPayload: (() => { try { return JSON.parse(item.outputPayload); } catch { return {}; } })()
    }));

    return NextResponse.json({ executions: enriched });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
