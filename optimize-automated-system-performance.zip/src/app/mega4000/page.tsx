"use client";

import React, { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Mega4000PracticalDominanceEngine } from "@/components/Mega4000PracticalDominanceEngine";
import { WeatherMatrixFloatingFolder } from "@/components/WeatherMatrixFloatingFolder";
import { Trophy, ShieldCheck } from "lucide-react";

export default function Mega4000Page() {
  const [activeTab, setActiveTab] = useState("mega4000");
  const [isAutoPilot, setIsAutoPilot] = useState(true);

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-100 selection:bg-cyan-500 flex flex-col">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isAutoPilot={isAutoPilot}
        toggleAutoPilot={() => setIsAutoPilot(!isAutoPilot)}
        refreshAll={() => {
          if (typeof window !== "undefined") window.location.reload();
        }}
        isLoading={false}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-12">
        <Mega4000PracticalDominanceEngine />
      </main>

      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-medium">
          <div className="flex items-center space-x-2">
            <Trophy className="w-4 h-4 text-cyan-400 shrink-0" />
            <span className="text-white font-extrabold">Live Weather Metrics 360 • Owner: Hassan Asghar</span>
            <span>•</span>
            <span className="text-emerald-400 font-bold">4,000 Practical Tricks Online • Zero Bugs Forever</span>
          </div>
          <span className="text-cyan-300 font-mono">100% Reality &amp; Structural Perfection</span>
        </div>
      </footer>

      <WeatherMatrixFloatingFolder
        onNavigate={(tab) => {
          if (typeof window !== "undefined") window.location.href = `/?tab=${tab}`;
        }}
        onTriggerBugScan={async () => {
          await fetch("/api/incidents/auto-heal", { method: "POST", body: JSON.stringify({ type: "watchdog_scan" }) });
          alert("✅ Autonomous Self-Healing complete! Zero bugs present.");
        }}
      />
    </div>
  );
}
