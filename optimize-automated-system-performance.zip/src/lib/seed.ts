import { db } from "@/db";
import { workflows, workflowNodes, executions, systemIncidents, automationSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function seedInitialData() {
  const existingWorkflows = await db.select().from(workflows);
  if (existingWorkflows.length > 0) {
    return { status: "already_seeded" };
  }

  // Seed Workflows
  const sampleWorkflows = [
    {
      id: "wf-devops-healing",
      name: "Autonomous Server Error Deflection & Pool Recovery",
      description: "Monitors PostgreSQL lock contentions and latency spikes; automatically clears stalled transactions and flushes Redis cache without human intervention.",
      category: "SRE & DevOps",
      status: "active",
      triggerType: "error_alert",
      triggerConfig: JSON.stringify({ condition: "Latency > 400ms OR Locks > 5", endpoint: "/api/webhooks/pg-monitor" }),
      executionCount: 64,
      successCount: 64,
      lastRunAt: new Date(Date.now() - 1000 * 60 * 15),
    },
    {
      id: "wf-refund-fraud",
      name: "E-Commerce AI Refund & Fraud Check Verification",
      description: "Processes instant refund requests via Stripe webhook, runs AI fraud scoring, verifies customer lifetime value, and emails automated receipts.",
      category: "Finance & Security",
      status: "active",
      triggerType: "webhook",
      triggerConfig: JSON.stringify({ endpoint: "/api/webhooks/refunds-v2", method: "POST", auth: "Bearer Token" }),
      executionCount: 182,
      successCount: 179,
      lastRunAt: new Date(Date.now() - 1000 * 60 * 42),
    },
    {
      id: "wf-support-triage",
      name: "Customer Ticket AI Sentiment & Auto-Response",
      description: "Analyzes incoming Zendesk/Email customer queries with LLM sentiment extraction, resolves Level-1 repetitive requests, and alerts team on Slack if urgent.",
      category: "Support AI",
      status: "active",
      triggerType: "webhook",
      triggerConfig: JSON.stringify({ endpoint: "/api/webhooks/support-desk", method: "POST" }),
      executionCount: 245,
      successCount: 243,
      lastRunAt: new Date(Date.now() - 1000 * 60 * 110),
    },
    {
      id: "wf-data-sync",
      name: "Nightly Database Maintenance & Table Defragmenter",
      description: "Automated cron job that executes VACUUM ANALYZE, reindexes heavy analytical tables, archives out-of-date logs to cold S3 storage, and updates metrics.",
      category: "Data & AI",
      status: "active",
      triggerType: "schedule",
      triggerConfig: JSON.stringify({ cron: "0 2 * * *", timezone: "UTC", nextRun: "02:00:00 UTC" }),
      executionCount: 120,
      successCount: 120,
      lastRunAt: new Date(Date.now() - 1000 * 3600 * 12),
    },
    {
      id: "wf-security-watch",
      name: "DDoS Deflector & API Rate Limit IP Shield",
      description: "Watches API edge proxies for traffic bursts exceeding 60 req/sec from suspicious subnets and dynamically writes WAF blocking rules in sub-second time.",
      category: "Security",
      status: "active",
      triggerType: "threshold",
      triggerConfig: JSON.stringify({ threshold: "60 requests / second", window: "30s block" }),
      executionCount: 312,
      successCount: 312,
      lastRunAt: new Date(Date.now() - 1000 * 60 * 5),
    },
    {
      id: "wf-weathermatrix-shield",
      name: "Live WeatherMatrix Storm & Anomaly Alert Shield",
      description: "Ingests live atmospheric telemetry from satellite Doppler matrix sensors; predicts flash storm fronts via AI neural climate models and triggers emergency routing protocols.",
      category: "WeatherMatrix AI",
      status: "active",
      triggerType: "threshold",
      triggerConfig: JSON.stringify({ threshold: "Barometric Drop > 8 mb/hr OR Radar Reflectivity > 55 dBZ", station: "WX-MATRIX-NODE-01" }),
      executionCount: 418,
      successCount: 418,
      lastRunAt: new Date(Date.now() - 1000 * 60 * 2),
    }
  ];

  for (const wf of sampleWorkflows) {
    await db.insert(workflows).values(wf);
  }

  // Seed Workflow Nodes
  const sampleNodes = [
    // WeatherMatrix Shield Nodes
    { id: "node-wx1", workflowId: "wf-weathermatrix-shield", label: "Live Doppler Satellite Stream Ingest", nodeType: "trigger", actionType: "Atmospheric Sensor Reader", config: JSON.stringify({ frequency: "Sub-Second Pulse", radarGrid: "WeatherMatrix 360°" }), stepOrder: 1 },
    { id: "node-wx2", workflowId: "wf-weathermatrix-shield", label: "AI Neural Front Prediction", nodeType: "ai", actionType: "Storm Trajectory Modeler", config: JSON.stringify({ model: "ClimateNet-Pro-V6", accuracy: "99.9%" }), stepOrder: 2 },
    { id: "node-wx3", workflowId: "wf-weathermatrix-shield", label: "Verify Emergency Flood Thresholds", nodeType: "condition", actionType: "Regional Threshold Evaluator", config: JSON.stringify({ rule: "windSpeed >= 65 OR precipitationRate >= 2.5 in/hr" }), stepOrder: 3 },
    { id: "node-wx4", workflowId: "wf-weathermatrix-shield", label: "Broadcast Instant Warning Protocol", nodeType: "notification", actionType: "Emergency Broadcast Siren & SMS", config: JSON.stringify({ target: "All Pinned Users & WeatherMatrix Folder Consoles", responseTime: "0.2s" }), stepOrder: 4 },
    // DevOps Healing Nodes
    { id: "node-d1", workflowId: "wf-devops-healing", label: "DB Lock & Error Trigger", nodeType: "trigger", actionType: "Error Threshold Monitor", config: JSON.stringify({ source: "Postgres PgStat", thresholdMs: 400 }), stepOrder: 1 },
    { id: "node-d2", workflowId: "wf-devops-healing", label: "Analyze Stalled Queries", nodeType: "ai", actionType: "SQL Query Diagnostics", config: JSON.stringify({ mode: "Detect deadlocks & idle in transaction" }), stepOrder: 2 },
    { id: "node-d3", workflowId: "wf-devops-healing", label: "Terminate Blocking PIDs", nodeType: "action", actionType: "Execute Auto-Remediation", config: JSON.stringify({ query: "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE wait_event_type = 'Lock';" }), stepOrder: 3 },
    { id: "node-d4", workflowId: "wf-devops-healing", label: "Broadcast SRE Slack Alert", nodeType: "notification", actionType: "Slack Webhook Broadcast", config: JSON.stringify({ channel: "#devops-autoheal", template: "✅ Bug & DB contention auto-healed in {{duration}}ms!" }), stepOrder: 4 },

    // Refund Fraud Nodes
    { id: "node-r1", workflowId: "wf-refund-fraud", label: "Receive Refund Webhook", nodeType: "trigger", actionType: "Incoming POST Webhook", config: JSON.stringify({ payloadSchema: { orderId: "string", amount: "number", userId: "string" } }), stepOrder: 1 },
    { id: "node-r2", workflowId: "wf-refund-fraud", label: "AI Fraud Score Evaluation", nodeType: "ai", actionType: "AI Neural Risk Model", config: JSON.stringify({ model: "FraudSense-v4", riskThreshold: 0.15 }), stepOrder: 2 },
    { id: "node-r3", workflowId: "wf-refund-fraud", label: "Check User LTV & History", nodeType: "condition", actionType: "SQL Profile Verification", config: JSON.stringify({ condition: "orders_count >= 1 AND return_rate < 0.20" }), stepOrder: 3 },
    { id: "node-r4", workflowId: "wf-refund-fraud", label: "Execute Stripe Gateway Refund", nodeType: "action", actionType: "REST API Integration", config: JSON.stringify({ endpoint: "https://api.stripe.com/v1/refunds", method: "POST" }), stepOrder: 4 },
    { id: "node-r5", workflowId: "wf-refund-fraud", label: "Send Customer Receipt Email", nodeType: "notification", actionType: "Automated Email Sync", config: JSON.stringify({ subject: "Your automated refund has been processed instantly!" }), stepOrder: 5 },

    // Support Triage Nodes
    { id: "node-s1", workflowId: "wf-support-triage", label: "Inbound Support Ticket", nodeType: "trigger", actionType: "Webhook Listener", config: JSON.stringify({ format: "JSON Triage" }), stepOrder: 1 },
    { id: "node-s2", workflowId: "wf-support-triage", label: "LLM Sentiment & Topic Classifier", nodeType: "ai", actionType: "Natural Language Processor", config: JSON.stringify({ tags: ["Billing", "Technical Bug", "Feature Request", "Urgent"] }), stepOrder: 2 },
    { id: "node-s3", workflowId: "wf-support-triage", label: "Match Knowledge Base Solution", nodeType: "action", actionType: "Vector Semantic Search", config: JSON.stringify({ confidenceMin: 88 }), stepOrder: 3 },
    { id: "node-s4", workflowId: "wf-support-triage", label: "Dispatch Auto-Reply or Escalate", nodeType: "action", actionType: "Conditional Router", config: JSON.stringify({ route: "If confidence > 88% send Auto-Reply, else assign Level-2 engineer" }), stepOrder: 4 },

    // Data Sync Nodes
    { id: "node-c1", workflowId: "wf-data-sync", label: "Nightly Schedule (02:00 UTC)", nodeType: "trigger", actionType: "Cron Clock Trigger", config: JSON.stringify({ schedule: "0 2 * * *" }), stepOrder: 1 },
    { id: "node-c2", workflowId: "wf-data-sync", label: "Run PostgreSQL VACUUM ANALYZE", nodeType: "action", actionType: "Database Optimization", config: JSON.stringify({ tables: ["executions", "system_incidents", "audit_logs"] }), stepOrder: 2 },
    { id: "node-c3", workflowId: "wf-data-sync", label: "Archive Old Telemetry to S3", nodeType: "action", actionType: "Cloud Object Storage Backup", config: JSON.stringify({ bucket: "nexus-auto-backups-2026", format: "Parquet" }), stepOrder: 3 },

    // Security Watch Nodes
    { id: "node-x1", workflowId: "wf-security-watch", label: "Edge Traffic Anomaly Detection", nodeType: "trigger", actionType: "High Volume Sensor", config: JSON.stringify({ rateLimit: 60 }), stepOrder: 1 },
    { id: "node-x2", workflowId: "wf-security-watch", label: "Extract Attacker Subnets", nodeType: "ai", actionType: "IP Intelligence API", config: JSON.stringify({ filter: "Known Bots & Tor Exit Nodes" }), stepOrder: 2 },
    { id: "node-x3", workflowId: "wf-security-watch", label: "Deploy Instant Firewall Block", nodeType: "action", actionType: "WAF Dynamic Rule Set", config: JSON.stringify({ ttl: 3600, action: "DROP" }), stepOrder: 3 }
  ];

  for (const node of sampleNodes) {
    await db.insert(workflowNodes).values(node);
  }

  // Seed recent historical Executions
  const sampleExecutions = [
    {
      id: "exec-9081",
      workflowId: "wf-devops-healing",
      workflowName: "Autonomous Server Error Deflection & Pool Recovery",
      status: "healed",
      triggerSource: "Watchdog Alert",
      durationMs: 312,
      logs: JSON.stringify([
        { step: 1, node: "DB Lock & Error Trigger", status: "warn", message: "Detected 6 waiting lock queries on orders table.", durationMs: 45 },
        { step: 2, node: "Analyze Stalled Queries", status: "ok", message: "AI identified runaway reporting script consuming 100% CPU lock.", durationMs: 120 },
        { step: 3, node: "Terminate Blocking PIDs", status: "ok", message: "Terminated PID 44102 cleanly. Lock contention drop to 0.", durationMs: 89 },
        { step: 4, node: "Broadcast SRE Slack Alert", status: "ok", message: "Slack notification sent to #devops-autoheal.", durationMs: 58 }
      ]),
      outputPayload: JSON.stringify({ status: "RESOLVED", deadlocksCleared: 1, pidsTerminated: [44102], recoveryTimeMs: 312, systemStability: "100% Stable" }),
      errorDetails: "Stalling lock anomaly in transaction pool -> Cleanly healed without downtime.",
      executedAt: new Date(Date.now() - 1000 * 60 * 15),
    },
    {
      id: "exec-9082",
      workflowId: "wf-refund-fraud",
      workflowName: "E-Commerce AI Refund & Fraud Check Verification",
      status: "completed",
      triggerSource: "Webhook Event",
      durationMs: 440,
      logs: JSON.stringify([
        { step: 1, node: "Receive Refund Webhook", status: "ok", message: "Parsed valid payload for Order #ORD-89421 ($149.99).", durationMs: 25 },
        { step: 2, node: "AI Fraud Score Evaluation", status: "ok", message: "Risk Score: 0.04 (Very Low). Device Fingerprint verified.", durationMs: 180 },
        { step: 3, node: "Check User LTV & History", status: "ok", message: "Customer account age: 3.2 years. LTV: $2,410.00. Approved.", durationMs: 60 },
        { step: 4, node: "Execute Stripe Gateway Refund", status: "ok", message: "Stripe Charge ch_3P9aB12L refunded successfully.", durationMs: 140 },
        { step: 5, node: "Send Customer Receipt Email", status: "ok", message: "Automated confirmation sent to alex@example.com.", durationMs: 35 }
      ]),
      outputPayload: JSON.stringify({ refundApproved: true, orderId: "ORD-89421", amountRefunded: "$149.99", fraudRiskScore: 0.04, customerStatus: "VIP Trusted" }),
      errorDetails: null,
      executedAt: new Date(Date.now() - 1000 * 60 * 42),
    },
    {
      id: "exec-9083",
      workflowId: "wf-support-triage",
      workflowName: "Customer Ticket AI Sentiment & Auto-Response",
      status: "completed",
      triggerSource: "Webhook Event",
      durationMs: 290,
      logs: JSON.stringify([
        { step: 1, node: "Inbound Support Ticket", status: "ok", message: "Received ticket #TKT-4412: 'How do I export CSV bills?'", durationMs: 30 },
        { step: 2, node: "LLM Sentiment & Topic Classifier", status: "ok", message: "Sentiment: Positive/Inquiry. Topic: Billing & Exports.", durationMs: 130 },
        { step: 3, node: "Match Knowledge Base Solution", status: "ok", message: "Found KB Article #91: 'Exporting Billing Statements to CSV & PDF'. Confidence 99.4%.", durationMs: 70 },
        { step: 4, node: "Dispatch Auto-Reply", status: "ok", message: "Dispatched direct guided response with one-click export link.", durationMs: 60 }
      ]),
      outputPayload: JSON.stringify({ ticketId: "TKT-4412", action: "AUTO_RESOLVE", kbMatch: "KB-91", confidence: "99.4%", timeSavedMin: 15 }),
      errorDetails: null,
      executedAt: new Date(Date.now() - 1000 * 60 * 110),
    }
  ];

  for (const ex of sampleExecutions) {
    await db.insert(executions).values(ex);
  }

  // Seed System Incidents (Auto-healed bug reports & live watchdog events)
  const sampleIncidents = [
    {
      id: "inc-101",
      title: "Memory Leak Detected on Worker Node #14 (Potential OutOfMemory Error)",
      service: "Worker Queue Pod",
      severity: "high",
      status: "auto_healed",
      symptom: "Heap memory usage crossed 88% with degrading garbage collection efficiency.",
      automatedAction: "Autonomous bot invoked graceful thread drain & re-provisioned Docker container instance.",
      resolutionTimeSec: 4,
      confidenceScore: 100,
      timestamp: new Date(Date.now() - 1000 * 60 * 25),
    },
    {
      id: "inc-102",
      title: "PostgreSQL Deadlock Condition in Simultaneous Checkout Transaction",
      service: "PostgreSQL Main Database",
      severity: "critical",
      status: "auto_healed",
      symptom: "Lock waiting timeout on table 'orders' during concurrent inventory debit.",
      automatedAction: "Executed automatic fallback lock retry scheme with jittered exponential backoff; queries completed.",
      resolutionTimeSec: 1,
      confidenceScore: 99,
      timestamp: new Date(Date.now() - 1000 * 60 * 75),
    },
    {
      id: "inc-103",
      title: "Expired Webhook Authentication Signature from External Partner",
      service: "API Edge Gateway",
      severity: "medium",
      status: "auto_healed",
      symptom: "401 Unauthorized spikes from webhook sender IP due to legacy timestamp sync drift.",
      automatedAction: "Auto-calibrated NTP clock delta (+420ms) and rotated secondary verification HMAC key.",
      resolutionTimeSec: 2,
      confidenceScore: 98,
      timestamp: new Date(Date.now() - 1000 * 3600 * 3),
    },
    {
      id: "inc-104",
      title: "Unresolved DNS Resolution Delay on S3 Backup Endpoint",
      service: "Nightly ETL Engine",
      severity: "low",
      status: "auto_healed",
      symptom: "AWS DNS resolver returned 504 Gateway Timeout during batch upload initialization.",
      automatedAction: "Swapped primary resolver to Cloudflare 1.1.1.1 backup tunnel and retried upload without loss.",
      resolutionTimeSec: 3,
      confidenceScore: 100,
      timestamp: new Date(Date.now() - 1000 * 3600 * 14),
    },
    {
      id: "inc-105",
      title: "Unexpected Null Pointer Risk in Order Processing Pipeline Bug #81",
      service: "Core Backend API",
      severity: "high",
      status: "auto_healed",
      symptom: "Undefined user address object passed from mobile app client v4.1.",
      automatedAction: "Injected automated null-safety validation shield and applied default fallback shipping object.",
      resolutionTimeSec: 2,
      confidenceScore: 99,
      timestamp: new Date(Date.now() - 1000 * 3600 * 22),
    }
  ];

  for (const inc of sampleIncidents) {
    await db.insert(systemIncidents).values(inc);
  }

  // Seed Automation Settings
  const sampleSettings = [
    { key: "auto_healing_enabled", value: "true", description: "Enable Autonomous AI Bug & Error Self-Healing Engine" },
    { key: "ai_model", value: "GPT-4o-Autonomous-Agent-v3", description: "Default AI Decision & Risk Classifier Engine" },
    { key: "max_concurrency", value: "500 worker jobs/sec", description: "Maximum Multi-Threaded Workflow Execution Concurrency" },
    { key: "watchdog_interval", value: "5 seconds", description: "System Bug Detector Ping Frequency" },
    { key: "retry_policy", value: "Exponential Backoff (3 retries max)", description: "Automated Failure & Network Error Retry Architecture" },
    { key: "notification_slack", value: "https://hooks.slack.com/services/NEXUS/AUTO/HEAL", description: "Webhooks for Live DevOps Alerts & Debug Reports" },
  ];

  for (const st of sampleSettings) {
    await db.insert(automationSettings).values(st);
  }

  return { status: "seeded" };
}
