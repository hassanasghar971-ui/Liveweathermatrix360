"use client";
import WeatherMatrixPage from "@/app/weathermatrix/page";
export default function FolderPage() {
  return <WeatherMatrixPage />;
}
