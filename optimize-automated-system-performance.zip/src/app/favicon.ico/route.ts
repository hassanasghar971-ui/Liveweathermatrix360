import { NextResponse } from "next/server";
import { ImageResponse } from "next/og";
import React from "react";

export const runtime = "edge";

export async function GET() {
  return new ImageResponse(
    React.createElement(
      "div",
      {
        style: {
          fontSize: 24,
          background: "#06b6d4",
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "white",
          borderRadius: 6,
          fontWeight: 900,
        },
      },
      "⚡"
    ),
    {
      width: 32,
      height: 32,
    }
  );
}
