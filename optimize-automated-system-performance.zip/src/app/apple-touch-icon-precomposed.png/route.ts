import { GET as handler } from "@/app/apple-touch-icon.png/route";
export const runtime = "edge";
export const GET = handler;
