import { GET as getHandler, POST as postHandler } from "@/app/api/webhook/route";

export const GET = getHandler;
export const POST = postHandler;
