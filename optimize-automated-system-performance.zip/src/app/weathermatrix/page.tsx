"use client";

import React, { useState, useEffect } from "react";
import { Navbar } from "@/components/Navbar";
import { DashboardOverview } from "@/components/DashboardOverview";
import { WorkflowStudio } from "@/components/WorkflowStudio";
import { BugWatchdog } from "@/components/BugWatchdog";
import { ExecutionHistory } from "@/components/ExecutionHistory";
import { SystemSettings } from "@/components/SystemSettings";
import { WeatherMatrixFloatingFolder } from "@/components/WeatherMatrixFloatingFolder";
import { WorldNo1SEODominance } from "@/components/WorldNo1SEODominance";
import { CloudLightning, Radio, ShieldCheck, Activity, RefreshCw, Wind, Droplets, Compass, Thermometer } from "lucide-react";
import Link from "next/link";

export default function WeatherMatrixPage() {
  const [activeTab, setActiveTab] = useState("studio");
  const [isLoading, setIsLoading] = useState(false);
  const [isAutoPilot, setIsAutoPilot] = useState(true);
  
  const [metrics, setMetrics] = useState<any>({});
  const [workflows, setWorkflows] = useState<any[]>([]);
  const [executions, setExecutions] = useState<any[]>([]);
  const [incidents, setIncidents] = useState<any[]>([]);
  const [settings, setSettings] = useState<any[]>([]);

  const fetchAllTelemetry = async () => {
    try {
      setIsLoading(true);
      const initRes = await fetch("/api/init");
      if (initRes.ok) setMetrics((await initRes.json()).metrics || {});
      const wfRes = await fetch("/api/workflows");
      if (wfRes.ok) setWorkflows((await wfRes.json()).workflows || []);
      const exRes = await fetch("/api/executions");
      if (exRes.ok) setExecutions((await exRes.json()).executions || []);
      const incRes = await fetch("/api/incidents");
      if (incRes.ok) setIncidents((await incRes.json()).incidents || []);
      const stRes = await fetch("/api/settings");
      if (stRes.ok) setSettings((await stRes.json()).settings || []);
    } catch (e) {
      console.error("Telemetry fetch error:", e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAllTelemetry();
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-100 selection:bg-cyan-500 selection:text-slate-950 flex flex-col">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isAutoPilot={isAutoPilot}
        toggleAutoPilot={() => setIsAutoPilot(!isAutoPilot)}
        refreshAll={fetchAllTelemetry}
        isLoading={isLoading}
      />

      <div className="bg-gradient-to-r from-cyan-950 via-slate-900 to-indigo-950 border-b border-cyan-500/30 py-4 px-4 sm:px-8 text-center text-sm font-extrabold text-cyan-300 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-2">
          <CloudLightning className="w-5 h-5 text-cyan-400 animate-pulse shrink-0" />
          <span>LIVE WEATHERMATRIX DEDICATED HUB • 100% ONLINE (NO 404 ERRORS)</span>
        </div>
        <Link href="/" className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black text-xs transition shadow uppercase tracking-wider">
          Return to Master Dashboard →
        </Link>
      </div>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
        {/* WeatherMatrix Banner */}
        <div className="bg-slate-900/90 rounded-3xl p-8 border-2 border-cyan-500/50 shadow-[0_0_50px_rgba(6,182,212,0.25)] relative overflow-hidden text-left">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-3 max-w-3xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 font-extrabold text-xs border border-cyan-500/40">
                <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
                <span>Atmospheric Doppler Matrix Active • Pinned Folder Synchronized</span>
              </div>
              <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight">
                Live WeatherMatrix Storm Shield & Command Grid
              </h1>
              <p className="text-slate-300 text-sm md:text-base leading-relaxed">
                Welcome directly to the Live WeatherMatrix command hub! All endpoints, radar grids, and autonomous self-healing engines are active and docked to your display below.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 shrink-0">
              <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-center w-36">
                <Wind className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
                <div className="text-sm font-black text-white">14.2 mph</div>
                <div className="text-[10px] text-slate-400 uppercase font-bold">Doppler Wind</div>
              </div>
              <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-center w-36">
                <Compass className="w-5 h-5 text-indigo-400 mx-auto mb-1" />
                <div className="text-sm font-black text-emerald-400">1013 mb</div>
                <div className="text-[10px] text-slate-400 uppercase font-bold">Pressure Bar</div>
              </div>
            </div>
          </div>
        </div>

        {activeTab === "studio" && <WorkflowStudio workflows={workflows} onExecuteWorkflow={async () => {}} onRefresh={fetchAllTelemetry} />}
        {activeTab === "dashboard" && <DashboardOverview metrics={metrics} workflows={workflows} executions={executions} incidents={incidents} onNavigate={setActiveTab} onExecuteWorkflow={async () => {}} onTriggerBugScan={async () => {}} isExecuting={false} />}
        {activeTab === "watchdog" && <BugWatchdog incidents={incidents} onRefresh={fetchAllTelemetry} />}
        {activeTab === "logs" && <ExecutionHistory executions={executions} workflows={workflows} onRefresh={fetchAllTelemetry} />}
        {activeTab === "settings" && <SystemSettings settings={settings} onRefresh={fetchAllTelemetry} />}
        <WorldNo1SEODominance />
      </main>

      <WeatherMatrixFloatingFolder
        onNavigate={setActiveTab}
        onTriggerBugScan={async () => {
          await fetch("/api/incidents/auto-heal", { method: "POST", body: JSON.stringify({ type: "watchdog_scan" }) });
          fetchAllTelemetry();
        }}
      />
    </div>
  );
}
