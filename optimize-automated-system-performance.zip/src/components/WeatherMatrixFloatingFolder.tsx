"use client";

import React, { useState, useEffect } from "react";
import { CloudLightning, Folder, FolderOpen, Pin, PinOff, Zap, ShieldCheck, Activity, Compass, Wind, Droplets, Thermometer, Minimize2, Maximize2, X, RefreshCw, ExternalLink, Sparkles, Radio } from "lucide-react";

interface WeatherMatrixFloatingFolderProps {
  onNavigate: (tab: string) => void;
  onTriggerBugScan: () => void;
}

export const WeatherMatrixFloatingFolder: React.FC<WeatherMatrixFloatingFolderProps> = ({
  onNavigate,
  onTriggerBugScan,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isPinned, setIsPinned] = useState(true);
  const [activeSubTab, setActiveSubTab] = useState("radar");
  const [lastUpdate, setLastUpdate] = useState("Just now");

  // Live simulation variables for WeatherMatrix Telemetry
  const [temperature, setTemperature] = useState(72.4);
  const [humidity, setHumidity] = useState(58);
  const [windSpeed, setWindSpeed] = useState(14.2);
  const [pressure, setPressure] = useState(1013.2);
  const [radarStatus, setRadarStatus] = useState("Clear Grid • No Severe Anomalies");
  const [isScanning, setIsScanning] = useState(false);

  // Periodic pulse simulation for live feel
  useEffect(() => {
    const timer = setInterval(() => {
      if (!isScanning) {
        setTemperature((prev) => Number((prev + (Math.random() * 0.4 - 0.2)).toFixed(1)));
        setWindSpeed((prev) => Number((prev + (Math.random() * 0.6 - 0.3)).toFixed(1)));
        setPressure((prev) => Number((prev + (Math.random() * 0.2 - 0.1)).toFixed(1)));
      }
    }, 3500);
    return () => clearInterval(timer);
  }, [isScanning]);

  const handleSimulateStormScan = async () => {
    setIsScanning(true);
    setRadarStatus("⚡ SCANNING MATRIX... HIGH DOPPLER GAIN");
    await new Promise((r) => setTimeout(r, 1200));
    setWindSpeed(42.8);
    setHumidity(89);
    setPressure(998.4);
    setRadarStatus("🚨 STORM FRONT ALERT: Autonomous AI Defense Activated!");
    await new Promise((r) => setTimeout(r, 1800));
    setRadarStatus("✅ DEFLECTION COMPLETE: All emergency relays synchronized.");
    setIsScanning(false);
    setWindSpeed(16.5);
    setPressure(1012.8);
  };

  return (
    <div
      className={`fixed bottom-6 right-6 z-50 transition-all duration-300 ${
        !isPinned && !isOpen ? "opacity-75 hover:opacity-100 translate-y-1 hover:translate-y-0" : "opacity-100"
      }`}
    >
      {/* COLLAPSED FLOATING STUCK ICON / FOLDER WIDGET */}
      {!isOpen ? (
        <div className="flex flex-col items-end gap-2 group">
          {/* Tooltip badge on hover */}
          <div className="hidden group-hover:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-cyan-500/50 text-xs font-extrabold text-cyan-300 shadow-xl animate-bounce">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>Live WeatherMatrix & Quick-Folder Stays Pinned on Your Screen!</span>
          </div>

          <button
            onClick={() => setIsOpen(true)}
            className="relative flex items-center gap-3 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 hover:from-slate-800 hover:to-indigo-900 text-white p-3.5 sm:px-5 sm:py-3.5 rounded-3xl border-2 border-cyan-500/60 hover:border-cyan-400 shadow-[0_0_35px_rgba(6,182,212,0.45)] transition-all duration-300 scale-100 hover:scale-105 active:scale-95 group"
            title="Click to expand Live WeatherMatrix folder"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 via-sky-600 to-indigo-600 flex items-center justify-center shadow-md border border-cyan-300/40 animate-pulse shrink-0">
              <CloudLightning className="w-6 h-6 text-white" />
            </div>
            
            <div className="hidden sm:flex flex-col items-start pr-1">
              <div className="flex items-center gap-1.5">
                <span className="font-black text-sm tracking-tight bg-gradient-to-r from-cyan-300 via-sky-200 to-white bg-clip-text text-transparent">
                  WeatherMatrix Folder
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
              </div>
              <span className="text-[11px] text-cyan-300 font-bold flex items-center gap-2">
                <span>{temperature}°F • {windSpeed} mph</span>
                <span>•</span>
                <span className="text-slate-300 font-semibold underline decoration-cyan-500">Pinned & Docked</span>
              </span>
            </div>

            <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-cyan-400 shrink-0 group-hover:bg-cyan-500 group-hover:text-slate-950 transition">
              <FolderOpen className="w-4 h-4" />
            </div>
          </button>
        </div>
      ) : (
        /* EXPANDED INTERACTIVE DOCKED FOLDER & WEATHERMATRIX DASHBOARD */
        <div className="w-[360px] sm:w-[420px] bg-slate-900/95 backdrop-blur-xl rounded-3xl border-2 border-cyan-500/60 shadow-[0_0_60px_rgba(6,182,212,0.35)] overflow-hidden animate-in zoom-in-95 duration-200 text-slate-100 flex flex-col">
          
          {/* Header Bar */}
          <div className="bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 p-4 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-cyan-600 flex items-center justify-center text-white font-bold shadow">
                <CloudLightning className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-sm text-white">Live WeatherMatrix</span>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-cyan-950 text-cyan-300 border border-cyan-800">
                    Docked Folder
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Activity className="w-3 h-3 text-emerald-400 animate-pulse" /> Pinned to Screen • Quick Controls
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsPinned(!isPinned)}
                className={`p-2 rounded-xl border transition ${
                  isPinned
                    ? "bg-cyan-950/80 text-cyan-300 border-cyan-500/60 shadow"
                    : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"
                }`}
                title={isPinned ? "Pinned to Screen (Always Visible)" : "Unpinned"}
              >
                {isPinned ? <Pin className="w-3.5 h-3.5 fill-cyan-400" /> : <PinOff className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition border border-slate-700"
                title="Minimize Folder to Icon"
              >
                <Minimize2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Sub-navigation items */}
          <div className="flex border-b border-slate-800/90 bg-slate-950/70 text-xs font-bold">
            <button
              onClick={() => setActiveSubTab("radar")}
              className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 transition border-r border-slate-800/80 ${
                activeSubTab === "radar" ? "bg-cyan-500/10 text-cyan-300 border-b-2 border-b-cyan-400 font-extrabold" : "text-slate-400 hover:text-white"
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Matrix Radar</span>
            </button>
            <button
              onClick={() => setActiveSubTab("shortcuts")}
              className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 transition border-r border-slate-800/80 ${
                activeSubTab === "shortcuts" ? "bg-cyan-500/10 text-cyan-300 border-b-2 border-b-cyan-400 font-extrabold" : "text-slate-400 hover:text-white"
              }`}
            >
              <Folder className="w-3.5 h-3.5" />
              <span>Quick Folder</span>
            </button>
            <button
              onClick={() => setActiveSubTab("info")}
              className={`flex-1 py-2.5 flex items-center justify-center gap-1.5 transition ${
                activeSubTab === "info" ? "bg-cyan-500/10 text-cyan-300 border-b-2 border-b-cyan-400 font-extrabold" : "text-slate-400 hover:text-white"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Screen Pinning</span>
            </button>
          </div>

          {/* Tab Content */}
          <div className="p-4 space-y-4 max-h-[420px] overflow-y-auto">
            {activeSubTab === "radar" && (
              <>
                {/* Simulated Radar Matrix Grid Display */}
                <div className="relative bg-slate-950 rounded-2xl p-4 border border-slate-800 text-center overflow-hidden shadow-inner">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.1)_0%,transparent_70%)] pointer-events-none" />
                  <div className="flex items-center justify-between text-[11px] font-mono text-cyan-400 mb-2 border-b border-slate-900 pb-1.5">
                    <span>GRID: WX-MATRIX-360</span>
                    <span className="flex items-center gap-1 font-bold text-emerald-400">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" /> ONLINE & SYNCED
                    </span>
                  </div>
                  
                  {/* Live Metrics Row */}
                  <div className="grid grid-cols-4 gap-2 py-2">
                    <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800/80">
                      <Thermometer className="w-4 h-4 text-amber-400 mx-auto mb-1" />
                      <div className="text-xs font-black text-white">{temperature}°F</div>
                      <div className="text-[9px] font-semibold text-slate-400 uppercase">Temp</div>
                    </div>
                    <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800/80">
                      <Wind className="w-4 h-4 text-cyan-400 mx-auto mb-1" />
                      <div className="text-xs font-black text-cyan-300">{windSpeed}</div>
                      <div className="text-[9px] font-semibold text-slate-400 uppercase">MPH Wind</div>
                    </div>
                    <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800/80">
                      <Droplets className="w-4 h-4 text-sky-400 mx-auto mb-1" />
                      <div className="text-xs font-black text-white">{humidity}%</div>
                      <div className="text-[9px] font-semibold text-slate-400 uppercase">Humidity</div>
                    </div>
                    <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800/80">
                      <Compass className="w-4 h-4 text-indigo-400 mx-auto mb-1" />
                      <div className="text-xs font-black text-slate-200">{pressure}</div>
                      <div className="text-[9px] font-semibold text-slate-400 uppercase">Pressure mb</div>
                    </div>
                  </div>

                  {/* Status Box */}
                  <div className="mt-2 p-2.5 rounded-xl bg-cyan-950/40 border border-cyan-800/50 text-left">
                    <div className="text-[11px] font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                      <span>⚡ TELEMETRY STATUS:</span>
                    </div>
                    <p className="text-[11px] text-slate-300 font-medium leading-tight mt-0.5">
                      {radarStatus}
                    </p>
                  </div>
                </div>

                {/* Radar Actions */}
                <div className="space-y-2">
                  <button
                    onClick={handleSimulateStormScan}
                    disabled={isScanning}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 via-indigo-600 to-cyan-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-extrabold text-xs uppercase tracking-wider shadow transition flex items-center justify-center gap-2 border border-cyan-400/40 disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? "animate-spin text-white" : ""}`} />
                    <span>{isScanning ? "Scanning Atmospheric Matrix..." : "Trigger WeatherMatrix Storm & AI Defense Simulation"}</span>
                  </button>
                  <button
                    onClick={() => { setIsOpen(false); onNavigate("studio"); }}
                    className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition flex items-center justify-center gap-1.5 border border-slate-700"
                  >
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    <span>Open WeatherMatrix Workflow Studio</span>
                  </button>
                </div>
              </>
            )}

            {activeSubTab === "shortcuts" && (
              <div className="space-y-3">
                <p className="text-xs text-slate-300 font-medium leading-relaxed">
                  This docked quick-folder is pinned to your screen so you can immediately trigger actions from anywhere without navigating away from your work.
                </p>

                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    onClick={() => { setIsOpen(false); onTriggerBugScan(); }}
                    className="p-3 rounded-2xl bg-slate-950 hover:bg-slate-800/80 border border-emerald-500/40 hover:border-emerald-400 text-left transition group shadow flex flex-col justify-between"
                  >
                    <ShieldCheck className="w-6 h-6 text-emerald-400 mb-2 group-hover:scale-110 transition" />
                    <div>
                      <div className="font-extrabold text-xs text-white">Trigger Auto-Heal</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Eliminate active bugs</div>
                    </div>
                  </button>

                  <button
                    onClick={() => { setIsOpen(false); onNavigate("watchdog"); }}
                    className="p-3 rounded-2xl bg-slate-950 hover:bg-slate-800/80 border border-cyan-500/40 hover:border-cyan-400 text-left transition group shadow flex flex-col justify-between"
                  >
                    <Activity className="w-6 h-6 text-cyan-400 mb-2 group-hover:scale-110 transition" />
                    <div>
                      <div className="font-extrabold text-xs text-white">Watchdog Console</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Paste & fix buggy code</div>
                    </div>
                  </button>

                  <button
                    onClick={() => { setIsOpen(false); onNavigate("logs"); }}
                    className="p-3 rounded-2xl bg-slate-950 hover:bg-slate-800/80 border border-indigo-500/40 hover:border-indigo-400 text-left transition group shadow flex flex-col justify-between"
                  >
                    <Folder className="w-6 h-6 text-indigo-400 mb-2 group-hover:scale-110 transition" />
                    <div>
                      <div className="font-extrabold text-xs text-white">Inspect Logs</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">View sub-second runs</div>
                    </div>
                  </button>

                  <button
                    onClick={() => { setIsOpen(false); onNavigate("settings"); }}
                    className="p-3 rounded-2xl bg-slate-950 hover:bg-slate-800/80 border border-amber-500/40 hover:border-amber-400 text-left transition group shadow flex flex-col justify-between"
                  >
                    <Sparkles className="w-6 h-6 text-amber-400 mb-2 group-hover:scale-110 transition" />
                    <div>
                      <div className="font-extrabold text-xs text-white">Engine Settings</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Adjust worker queue</div>
                    </div>
                  </button>
                </div>
              </div>
            )}

            {activeSubTab === "info" && (
              <div className="space-y-3.5 text-left">
                <div className="bg-gradient-to-r from-cyan-950 to-indigo-950 p-3 rounded-2xl border border-cyan-500/40">
                  <h4 className="font-extrabold text-xs text-cyan-300 flex items-center gap-1.5 mb-1">
                    <Pin className="w-3.5 h-3.5 fill-cyan-400" />
                    <span>How Screen Pinning Works</span>
                  </h4>
                  <p className="text-xs text-slate-200 leading-relaxed">
                    When anyone opens your live WeatherMatrix website, this interactive widget is permanently docked onto their display (using fixed layering <code className="text-cyan-300 bg-slate-950 px-1 rounded">z-50</code>). It never scrolls away!
                  </p>
                </div>

                <div className="space-y-2">
                  <h5 className="font-bold text-xs text-slate-300 uppercase tracking-wider">Why engineers love this:</h5>
                  <ul className="space-y-1.5 text-xs text-slate-300 list-disc list-inside">
                    <li><strong>Instant Access:</strong> Users never lose track of weather alerts or automated pipeline triggers.</li>
                    <li><strong>Expandable & Minimizable:</strong> Can collapse into a glowing folder icon or open into a full command center.</li>
                    <li><strong>Desktop / Mobile PWA Ready:</strong> Users can install this website directly to their Desktop taskbar or iPhone home screen!</li>
                  </ul>
                </div>

                <button
                  onClick={() => { alert("WeatherMatrix Folder is pinned! Tip: You can also use your browser menu ('Install App' or 'Add to Desktop') to stick an icon straight onto your computer desktop!"); }}
                  className="w-full py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs transition shadow flex items-center justify-center gap-2"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Test Desktop Icon Pinning Info</span>
                </button>
              </div>
            )}
          </div>

          {/* Footer Bar */}
          <div className="bg-slate-950 px-4 py-2.5 border-t border-slate-800 text-[10px] font-bold text-slate-400 flex items-center justify-between">
            <span>WeatherMatrix Node: WX-01</span>
            <button
              onClick={() => setIsOpen(false)}
              className="text-cyan-400 hover:text-cyan-300 underline font-extrabold"
            >
              Minimize Folder
            </button>
          </div>

        </div>
      )}
    </div>
  );
};
