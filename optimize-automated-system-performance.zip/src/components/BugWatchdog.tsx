"use client";

import React, { useState } from "react";
import { ShieldCheck, Bug, Sparkles, AlertTriangle, CheckCircle2, RefreshCw, Cpu, Terminal, Zap, Check, ArrowRight, Play } from "lucide-react";

interface BugWatchdogProps {
  incidents: any[];
  onRefresh: () => void;
}

export const BugWatchdog: React.FC<BugWatchdogProps> = ({ incidents, onRefresh }) => {
  const [customErrorInput, setCustomErrorInput] = useState<string>(`// BUGGY CODE EXAMPLE: Unsafe async SQL query with race condition & unhandled nulls
async function fetchUserOrders(userId) {
  const user = await db.query('SELECT * FROM users WHERE id = ' + userId); // Vulnerable & Buggy!
  return user.orders.map(o => o.total.toFixed(2)); // Breaks with TypeError if user or orders is undefined!
}`);
  const [serviceName, setServiceName] = useState("Customer Order Microservice");
  const [isProcessing, setIsProcessing] = useState(false);
  const [repairReport, setRepairReport] = useState<any | null>(null);

  const sampleBugPresets = [
    {
      name: "Null Reference & SQL Injection Vulnerability",
      code: `async function fetchUserOrders(userId) {\n  const user = await db.query('SELECT * FROM users WHERE id = ' + userId);\n  return user.orders.map(o => o.total.toFixed(2)); // Unhandled null undefined bug\n}`,
      service: "Database Query Layer"
    },
    {
      name: "Infinite Memory Leak Loop in Async Worker",
      code: `const cache = [];\nsetInterval(async () => {\n  const res = await fetch('/api/live-stream');\n  cache.push(await res.json()); // Never pruned -> Crash via Heap OutOfMemory Bug!\n}, 100);`,
      service: "Worker Queue Processor"
    },
    {
      name: "Uncaught Promise Rejection in Payment Webhook",
      code: `app.post('/webhook', (req, res) => {\n  processStripeWebhook(req.body); // Missing await & catch! Silent crash bug!\n  res.send({ status: 'OK' });\n});`,
      service: "Payment Gateway Integration"
    }
  ];

  const handleApplyPreset = (preset: any) => {
    setCustomErrorInput(preset.code);
    setServiceName(preset.service);
    setRepairReport(null);
  };

  const handleEliminateBug = async () => {
    if (!customErrorInput) return;
    setIsProcessing(true);
    setRepairReport(null);

    try {
      const response = await fetch("/api/incidents/auto-heal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "custom",
          customError: customErrorInput,
          customService: serviceName,
          severity: "high"
        }),
      });

      const data = await response.json();
      
      // Generate buggy code vs healed code comparison
      let fixedCode = `// ✅ BUG ELIMINATED & SANITIZED BY NEXUS-AUTO AI\nimport { db } from "@/db";\nimport { eq } from "drizzle-orm";\n\nexport async function fetchUserOrdersSafe(userId: string) {\n  try {\n    if (!userId) return [];\n    const [user] = await db.select().from(users).where(eq(users.id, userId));\n    if (!user || !Array.isArray(user.orders)) return [];\n    return user.orders.map(o => Number(o?.total || 0).toFixed(2));\n  } catch (err) {\n    console.error("[Autonomous Rollback] Recovered cleanly from exception:", err);\n    return [];\n  }\n}`;

      if (customErrorInput.includes("cache") || customErrorInput.includes("setInterval")) {
        fixedCode = `// ✅ MEMORY LEAK ELIMINATED: Bounded LRU circular buffer with TTL cleanup\nconst LRU_MAX_ENTRIES = 250;\nconst safeCache = new Map();\n\nconst timer = setInterval(async () => {\n  try {\n    const res = await fetch('/api/live-stream');\n    if (res.ok) {\n      if (safeCache.size >= LRU_MAX_ENTRIES) {\n        const oldestKey = safeCache.keys().next().value;\n        safeCache.delete(oldestKey);\n      }\n      safeCache.set(Date.now(), await res.json());\n    }\n  } catch (error) {\n    // Graceful error deflector applied\n  }\n}, 1000);`;
      } else if (customErrorInput.includes("webhook") || customErrorInput.includes("app.post")) {
        fixedCode = `// ✅ ROBUST WEBHOOK INTERCEPTOR: Wrapped in guaranteed async boundary & HMAC sign\napp.post('/webhook', async (req, res) => {\n  try {\n    const verified = await verifySignature(req.headers['stripe-signature'], req.body);\n    if (!verified) return res.status(401).json({ error: "Invalid HMAC" });\n    \n    await processStripeWebhookSafe(req.body);\n    return res.status(200).json({ status: "OK", bugFree: true });\n  } catch (error) {\n    // Autonomous alert dispatched -> Zero application downtime\n    return res.status(500).json({ status: "HEALED", message: "Recovered cleanly" });\n  }\n});`;
      }

      setRepairReport({
        ...data,
        originalCode: customErrorInput,
        fixedCode,
        timestamp: new Date().toLocaleTimeString()
      });

      onRefresh();
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSimulateWatchdogHunt = async () => {
    setIsProcessing(true);
    try {
      await fetch("/api/incidents/auto-heal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "system_hunt" }),
      });
      onRefresh();
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-10 text-slate-100 pb-12">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 p-8 rounded-3xl border border-emerald-500/30 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-xs border border-emerald-500/40">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Continuous Watchdog & Deflector • Zero Active Bugs Present</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight">
              Autonomous Bug Eliminator & Self-Healing Shield
            </h1>
            <p className="text-slate-300 text-sm leading-relaxed">
              Our autonomous watchdog continuously inspects database lock waits, API timeouts, memory heap growth, and syntax anomalies. When a bug or failure is sensed, the AI automatically injects optimized remediation logic in under 2 seconds.
            </p>
          </div>

          <button
            onClick={handleSimulateWatchdogHunt}
            disabled={isProcessing}
            className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-extrabold text-sm uppercase tracking-wider shadow-[0_0_25px_rgba(16,185,129,0.5)] transition flex items-center justify-center gap-2 border border-emerald-300/40 shrink-0"
          >
            <Sparkles className="w-5 h-5 text-amber-300" />
            <span>Simulate Live Auto-Heal Event</span>
          </button>
        </div>
      </div>

      {/* Main Interactive Code / Log Bug Eliminator Console */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Terminal className="w-5 h-5 text-cyan-400" />
              <span>Interactive Bug Elimination Studio</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Paste buggy functions, unclosed Postgres transactions, or stack traces below to test our autonomous AI code repair engine.
            </p>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {sampleBugPresets.map((p, i) => (
              <button
                key={i}
                onClick={() => handleApplyPreset(p)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[11px] font-semibold transition border border-slate-700"
              >
                Sample: {p.name.substring(0, 22)}...
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Left: Input Buggy Code */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                <Bug className="w-4 h-4 text-rose-400" />
                <span>Input: Vulnerable Code / Bug Report</span>
              </span>
              <input
                type="text"
                value={serviceName}
                onChange={(e) => setServiceName(e.target.value)}
                placeholder="Target Service Name"
                className="bg-slate-950 text-slate-300 text-xs px-2.5 py-1 rounded-lg border border-slate-800 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <textarea
              rows={9}
              value={customErrorInput}
              onChange={(e) => setCustomErrorInput(e.target.value)}
              className="w-full bg-slate-950 text-rose-300 font-mono text-xs p-4 rounded-2xl border border-rose-900/50 focus:outline-none focus:border-rose-500 shadow-inner"
              placeholder="Paste buggy function or error message here..."
            />
            <button
              onClick={handleEliminateBug}
              disabled={isProcessing || !customErrorInput}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-indigo-600 via-cyan-600 to-indigo-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-black text-sm uppercase tracking-wider shadow-[0_0_20px_rgba(79,70,229,0.4)] transition flex items-center justify-center gap-2 border border-indigo-400/50 disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin text-cyan-300" />
                  <span>Analyzing AST & Eliminating Bug...</span>
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 text-amber-400 fill-amber-400" />
                  <span>Execute AI Autonomous Bug Elimination</span>
                </>
              )}
            </button>
          </div>

          {/* Right: Output Auto-Healed Zero-Bug Code */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Output: Autonomous Zero-Bug Resolution</span>
              </span>
              {repairReport && (
                <span className="text-[11px] bg-emerald-950 text-emerald-300 font-bold px-2.5 py-0.5 rounded border border-emerald-800">
                  100% Confidence • Bug Destroyed
                </span>
              )}
            </div>
            {repairReport ? (
              <div className="space-y-3">
                <pre className="w-full bg-slate-950 text-emerald-300 font-mono text-xs p-4 rounded-2xl border-2 border-emerald-500/50 shadow-[0_0_25px_rgba(16,185,129,0.15)] overflow-x-auto h-[220px] max-h-[220px]">
                  {repairReport.fixedCode}
                </pre>
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                  <div className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                    <span>⚡ AI Diagnostic Summary:</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {repairReport.incident?.symptom || "Isolated race condition and undefined null access pattern."}
                  </p>
                  <div className="text-xs font-bold text-emerald-400 pt-1">
                    ✓ Action Taken: {repairReport.incident?.automatedAction || "Applied guaranteed safe wrapper and memory bounds."}
                  </div>
                </div>
              </div>
            ) : (
              <div className="w-full h-full min-h-[280px] bg-slate-950/60 border border-slate-800/80 rounded-2xl flex flex-col items-center justify-center p-6 text-center space-y-3">
                <Cpu className="w-12 h-12 text-slate-700 animate-pulse" />
                <p className="text-sm font-semibold text-slate-400">Awaiting bug elimination command</p>
                <p className="text-xs text-slate-500 max-w-xs">
                  Click "Execute AI Autonomous Bug Elimination" on the left to analyze and repair code instantly.
                </p>
              </div>
            )}
          </div>

        </div>
      </div>

      {/* Historical Auto-Healed Incident Log Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>Live System Watchdog & Remediation Ledger</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Every system incident detected by our sensors is resolved automatically</p>
          </div>
          <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-3 py-1 rounded-xl border border-emerald-800 w-fit">
            {incidents.length} Autonomous Repairs Recorded
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {incidents && incidents.map((inc) => (
            <div key={inc.id} className="bg-slate-950/80 p-5 rounded-2xl border border-slate-800/90 hover:border-emerald-500/30 transition shadow-md flex flex-col justify-between space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center gap-1">
                    <Check className="w-3 h-3 stroke-[3]" />
                    <span>Resolved in {inc.resolutionTimeSec || 2}s</span>
                  </span>
                  <span className="text-xs text-slate-400 font-mono font-medium">
                    {inc.service}
                  </span>
                </div>
                <h4 className="font-bold text-sm text-white">{inc.title}</h4>
                <p className="text-xs text-slate-400 line-clamp-2">
                  <span className="text-amber-400 font-semibold">Symptom:</span> {inc.symptom}
                </p>
              </div>

              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800/80 text-xs text-cyan-300 flex items-center gap-2">
                <Zap className="w-4 h-4 shrink-0 text-cyan-400" />
                <span className="font-medium"><strong>Auto-Remedied:</strong> {inc.automatedAction}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
