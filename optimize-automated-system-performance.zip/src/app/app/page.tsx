"use client";
import WeatherMatrixPage from "@/app/weathermatrix/page";
export default function AppPage() {
  return <WeatherMatrixPage />;
}
