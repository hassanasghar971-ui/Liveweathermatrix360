"use client";
import Mega4000Page from "@/app/mega4000/page";
export default function Brand1000AliasPage() {
  return <Mega4000Page />;
}
