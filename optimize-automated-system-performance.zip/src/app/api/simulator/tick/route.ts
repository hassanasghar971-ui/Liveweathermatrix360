import { NextResponse } from "next/server";
import { db } from "@/db";
import { workflows, workflowNodes, executions, systemIncidents } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST() {
  try {
    const activeWorkflows = await db.select().from(workflows).where(eq(workflows.status, "active"));
    if (activeWorkflows.length === 0) {
      return NextResponse.json({ message: "No active workflows to run in simulated loop" });
    }

    // Select a random workflow to execute
    const selectedWf = activeWorkflows[Math.floor(Math.random() * activeWorkflows.length)];
    const nodes = await db.select().from(workflowNodes).where(eq(workflowNodes.workflowId, selectedWf.id)).orderBy(workflowNodes.stepOrder);

    let durationMs = 0;
    const logs = nodes.map((n, idx) => {
      const stepTime = Math.floor(Math.random() * 90) + 20;
      durationMs += stepTime;
      return {
        step: idx + 1,
        node: n.label,
        nodeType: n.nodeType,
        status: "ok",
        message: `Autonomous scheduler completed ${n.actionType} verification. Zero faults encountered.`,
        durationMs: stepTime
      };
    });

    const executionId = `exec-auto-${Math.floor(Math.random() * 89999) + 10000}`;
    const outputString = JSON.stringify({ status: "SUCCESS", autoTrigger: "Simulated Cron / Autonomous Trigger", health: "Optimal" });

    await db.insert(executions).values({
      id: executionId,
      workflowId: selectedWf.id,
      workflowName: selectedWf.name,
      status: "completed",
      triggerSource: "Autonomous Cron / Watchdog Loop",
      durationMs,
      logs: JSON.stringify(logs),
      outputPayload: outputString,
      errorDetails: null,
      executedAt: new Date()
    });

    await db.update(workflows).set({
      executionCount: (selectedWf.executionCount || 0) + 1,
      successCount: (selectedWf.successCount || 0) + 1,
      lastRunAt: new Date(),
      updatedAt: new Date()
    }).where(eq(workflows.id, selectedWf.id));

    // Optionally generate a self-healed bug report (20% chance)
    let autoHealedIncident = null;
    if (Math.random() < 0.20) {
      const incidentId = `inc-${Math.floor(Math.random() * 8999) + 1000}`;
      const sampleBug = {
        id: incidentId,
        title: "Microservice Heartbeat Latency Jitter Detected",
        service: "Worker Orchestration Pool",
        severity: "medium",
        status: "auto_healed",
        symptom: "Ping response exceeded 120ms standard deviation benchmark.",
        automatedAction: "Autonomous engine routed worker traffic to secondary backup subnet; latency normalized instantly.",
        resolutionTimeSec: 1,
        confidenceScore: 100,
        timestamp: new Date()
      };
      await db.insert(systemIncidents).values(sampleBug);
      autoHealedIncident = sampleBug;
    }

    return NextResponse.json({
      success: true,
      executedWorkflow: selectedWf.name,
      executionId,
      durationMs,
      autoHealedIncident
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
