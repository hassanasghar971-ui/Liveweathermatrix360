"use client";

import React from "react";
import { Bot, ShieldCheck, Zap, Activity, Cpu, Sliders, Play, Square, Sparkles, RefreshCw, CloudLightning, Trophy } from "lucide-react";
import Link from "next/link";

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isAutoPilot: boolean;
  toggleAutoPilot: () => void;
  refreshAll: () => void;
  isLoading: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isAutoPilot,
  toggleAutoPilot,
  refreshAll,
  isLoading
}) => {
  const tabs = [
    { id: "dashboard", label: "Overview & Analytics", icon: Activity },
    { id: "mega4000", label: "4,000 Practical Tricks & Reality", icon: Trophy },
    { id: "metrics360", label: "Weather Metrics 360 (Hassan Asghar)", icon: CloudLightning },
    { id: "seo1000", label: "1,000 SEO Formulas", icon: Sparkles },
    { id: "studio", label: "Workflow Studio", icon: Zap },
    { id: "watchdog", label: "Bug Watchdog", icon: ShieldCheck },
    { id: "logs", label: "Live Telemetry", icon: Cpu },
    { id: "settings", label: "Settings", icon: Sliders },
  ];

  return (
    <header className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 shadow-2xl text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand & Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab("dashboard")}>
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-fuchsia-600 flex items-center justify-center shadow-[0_0_20px_rgba(79,70,229,0.5)] border border-cyan-400/50 animate-pulse">
              <CloudLightning className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-xl md:text-2xl tracking-tight bg-gradient-to-r from-cyan-300 via-sky-200 to-indigo-300 bg-clip-text text-transparent">
                  Live Weather Metrics 360
                </span>
                <span className="hidden lg:inline-block text-[10px] font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/40">
                  Owner: Hassan Asghar
                </span>
              </div>
              <p className="text-xs text-emerald-400 font-bold flex items-center gap-1.5 mt-0.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                135-Feature Automated Blog Engine • 0 Bugs Online
              </p>
            </div>
          </div>

          {/* Nav Tabs */}
          <nav className="hidden md:flex space-x-1 bg-slate-950/60 p-1.5 rounded-2xl border border-slate-800">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 ${
                    isActive
                      ? "bg-gradient-to-r from-indigo-600 to-indigo-500 text-white shadow-[0_4px_15px_rgba(79,70,229,0.4)] border border-indigo-400/40"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/60"
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? "text-cyan-300" : "text-slate-400"}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center space-x-3">
            <button
              onClick={refreshAll}
              disabled={isLoading}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              title="Refresh Telemetry & Database State"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin text-cyan-400" : ""}`} />
            </button>

            {/* Auto-Pilot Toggle Button */}
            <button
              onClick={toggleAutoPilot}
              className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all duration-300 shadow-lg ${
                isAutoPilot
                  ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-[0_0_25px_rgba(16,185,129,0.5)] border border-emerald-400"
                  : "bg-gradient-to-r from-slate-800 to-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 hover:border-slate-500"
              }`}
            >
              {isAutoPilot ? (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300 animate-spin" />
                  <span>Auto-Pilot Loop ON</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 text-emerald-400" />
                  <span>Start Auto-Pilot Simulator</span>
                </>
              )}
            </button>
          </div>

        </div>
      </div>
      
      {/* Mobile navigation row */}
      <div className="flex md:hidden overflow-x-auto bg-slate-950/80 px-4 py-2 space-x-2 border-t border-slate-800">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-1.5 whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-semibold ${
                isActive ? "bg-indigo-600 text-white" : "text-slate-400 bg-slate-800"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
