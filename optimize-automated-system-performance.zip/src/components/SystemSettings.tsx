"use client";

import React, { useState } from "react";
import { Sliders, ShieldCheck, Cpu, Bell, Save, CheckCircle2, Bot, Zap, RefreshCw } from "lucide-react";

interface SystemSettingsProps {
  settings: any[];
  onRefresh: () => void;
}

export const SystemSettings: React.FC<SystemSettingsProps> = ({ settings, onRefresh }) => {
  const [localSettings, setLocalSettings] = useState<Record<string, string>>(() => {
    const map: Record<string, string> = {
      auto_healing_enabled: "true",
      ai_model: "GPT-4o-Autonomous-Agent-v3",
      max_concurrency: "500 worker jobs/sec",
      watchdog_interval: "5 seconds",
      retry_policy: "Exponential Backoff (3 retries max)",
      notification_slack: "https://hooks.slack.com/services/NEXUS/AUTO/HEAL"
    };
    if (Array.isArray(settings)) {
      settings.forEach(s => { map[s.key] = s.value; });
    }
    return map;
  });
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const handleChange = (key: string, val: string) => {
    setLocalSettings(prev => ({ ...prev, [key]: val }));
    setSaveMessage(null);
  };

  const handleSaveAll = async () => {
    setIsSaving(true);
    setSaveMessage(null);
    try {
      for (const [key, value] of Object.entries(localSettings)) {
        await fetch("/api/settings", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key, value })
        });
      }
      setSaveMessage("All engine parameters committed cleanly to database.");
      onRefresh();
    } catch (e) {
      console.error(e);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-8 text-slate-100 max-w-4xl mx-auto pb-12">
      
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl space-y-8">
        <div className="flex items-center justify-between border-b border-slate-800 pb-6">
          <div>
            <h1 className="text-2xl font-black text-white flex items-center gap-2.5">
              <Sliders className="w-6 h-6 text-indigo-400" />
              <span>Automated Engine & Watchdog Configuration</span>
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Configure autonomous AI model architectures, zero-bug verification thresholds, and worker queues.
            </p>
          </div>
          
          <button
            onClick={handleSaveAll}
            disabled={isSaving}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-extrabold text-sm shadow-[0_4px_20px_rgba(79,70,229,0.4)] transition flex items-center gap-2 border border-indigo-400/50 disabled:opacity-50"
          >
            {isSaving ? <RefreshCw className="w-4 h-4 animate-spin text-white" /> : <Save className="w-4 h-4" />}
            <span>Commit Changes</span>
          </button>
        </div>

        {saveMessage && (
          <div className="p-4 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-sm font-semibold flex items-center gap-2.5 shadow-lg">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{saveMessage}</span>
          </div>
        )}

        <div className="space-y-6">
          
          {/* Section 1: AI Engine & Self-Healing */}
          <div className="bg-slate-950/70 p-6 rounded-2xl border border-slate-800/80 space-y-6">
            <h3 className="text-sm font-extrabold text-cyan-400 uppercase tracking-wider flex items-center gap-2 border-b border-slate-900 pb-3">
              <Bot className="w-4 h-4 text-cyan-400" />
              <span>Autonomous AI & Self-Healing Shield</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-2">Autonomous Self-Healing Engine</label>
                <select
                  value={localSettings["auto_healing_enabled"] || "true"}
                  onChange={(e) => handleChange("auto_healing_enabled", e.target.value)}
                  className="w-full bg-slate-900 text-white text-sm font-semibold p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-indigo-500"
                >
                  <option value="true">ENABLED (Auto-Detect & Eliminate All Bugs)</option>
                  <option value="false">DISABLED (Manual Incident Alerts Only)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-2">AI Diagnostic Decision Model</label>
                <select
                  value={localSettings["ai_model"] || "GPT-4o-Autonomous-Agent-v3"}
                  onChange={(e) => handleChange("ai_model", e.target.value)}
                  className="w-full bg-slate-900 text-white text-sm font-semibold p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-indigo-500"
                >
                  <option value="GPT-4o-Autonomous-Agent-v3">GPT-4o Autonomous Agent (Zero-Bug Precision)</option>
                  <option value="Claude-3.5-Sonnet-CodeHeal">Claude 3.5 Sonnet (Deep Syntax & SQL Optimizer)</option>
                  <option value="Nexus-Neural-Pro-v4">Nexus Neural Pro v4 (Sub-Second Latency)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 2: Concurrency & Watchdog Pulse */}
          <div className="bg-slate-950/70 p-6 rounded-2xl border border-slate-800/80 space-y-6">
            <h3 className="text-sm font-extrabold text-indigo-400 uppercase tracking-wider flex items-center gap-2 border-b border-slate-900 pb-3">
              <Cpu className="w-4 h-4 text-indigo-400" />
              <span>Performance Tuning & Watchdog Pulse</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-2">Max Multi-Threaded Concurrency</label>
                <input
                  type="text"
                  value={localSettings["max_concurrency"] || "500 worker jobs/sec"}
                  onChange={(e) => handleChange("max_concurrency", e.target.value)}
                  className="w-full bg-slate-900 text-white text-sm font-semibold p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-2">Watchdog Scan Frequency</label>
                <select
                  value={localSettings["watchdog_interval"] || "5 seconds"}
                  onChange={(e) => handleChange("watchdog_interval", e.target.value)}
                  className="w-full bg-slate-900 text-white text-sm font-semibold p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-indigo-500"
                >
                  <option value="1 second">Every 1 second (Ultra High-Speed Scan)</option>
                  <option value="5 seconds">Every 5 seconds (Recommended Enterprise)</option>
                  <option value="15 seconds">Every 15 seconds (Moderate Power)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 3: Webhooks & Notifications */}
          <div className="bg-slate-950/70 p-6 rounded-2xl border border-slate-800/80 space-y-6">
            <h3 className="text-sm font-extrabold text-emerald-400 uppercase tracking-wider flex items-center gap-2 border-b border-slate-900 pb-3">
              <Bell className="w-4 h-4 text-emerald-400" />
              <span>Alert Channels & Webhook Broadcast</span>
            </h3>

            <div>
              <label className="text-xs font-bold text-slate-300 block mb-2">Slack / Discord SRE Alert Webhook URL</label>
              <input
                type="text"
                value={localSettings["notification_slack"] || "https://hooks.slack.com/services/NEXUS/AUTO/HEAL"}
                onChange={(e) => handleChange("notification_slack", e.target.value)}
                className="w-full bg-slate-900 text-emerald-300 font-mono text-xs p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-indigo-500"
              />
              <p className="text-[11px] text-slate-500 mt-1.5">When an autonomous self-healing fix is applied, automated receipts are broadcast to this webhook.</p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
