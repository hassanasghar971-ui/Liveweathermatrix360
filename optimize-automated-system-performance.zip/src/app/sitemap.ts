import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = "https://hassanasghar.github.io/live-weather-metrics-360";
  const now = new Date().toISOString();

  const staticRoutes = [
    "",
    "/mega4000",
    "/working1000",
    "/structure1000",
    "/speed1000",
    "/brand1000",
    "/metrics360",
    "/seo1000",
    "/formulas",
    "/magic",
    "/brand",
    "/weathermatrix",
    "/radar",
    "/folder",
    "/blog",
    "/weather",
    "/matrix",
    "/dashboard",
    "/app"
  ];

  const cityKeywords = [
    "lahore-pakistan-weather-metrics-360",
    "karachi-pakistan-live-radar",
    "islamabad-pakistan-doppler-storm",
    "dubai-uae-heat-advisory",
    "london-uk-rain-radar",
    "new-york-usa-storm-warning",
    "tokyo-japan-typhoon-shield",
    "sydney-australia-coastal-surge",
    "toronto-canada-blizzard-watch",
    "berlin-germany-aqi-health",
    "mumbai-india-monsoon-radar",
    "doha-qatar-uv-index-gauge",
    "istanbul-turkey-aviation-delay",
    "riyadh-saudi-arabia-drought-shield",
    "singapore-humidity-advisory"
  ];

  const routes: MetadataRoute.Sitemap = staticRoutes.map((path) => ({
    url: `${baseUrl}${path}`,
    lastModified: now,
    changeFrequency: "hourly" as const,
    priority: path === "" || path === "/mega4000" || path === "/seo1000" ? 1.0 : 0.9,
  }));

  const dynamicCityRoutes: MetadataRoute.Sitemap = cityKeywords.map((slug) => ({
    url: `${baseUrl}/#${slug}`,
    lastModified: now,
    changeFrequency: "always" as const,
    priority: 0.85,
  }));

  return [...routes, ...dynamicCityRoutes];
}
