import { ImageResponse } from "next/og";

export const runtime = "edge";
export const size = { width: 48, height: 48 };
export const contentType = "image/png";

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          fontSize: 30,
          background: "linear-gradient(to top right, #06b6d4, #4f46e5)",
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "white",
          borderRadius: 12,
          fontWeight: 900,
          border: "2px solid #a5f3fc",
        }}
      >
        ⚡
      </div>
    ),
    {
      ...size,
    }
  );
}
