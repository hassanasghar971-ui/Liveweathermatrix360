import { ImageResponse } from "next/og";
import React from "react";

export const runtime = "edge";

export async function GET() {
  return new ImageResponse(
    React.createElement(
      "div",
      {
        style: {
          fontSize: 100,
          background: "linear-gradient(to bottom right, #06b6d4, #1e1b4b)",
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "white",
          borderRadius: 36,
          fontWeight: 900,
          border: "6px solid #a5f3fc",
        },
      },
      "⚡"
    ),
    {
      width: 180,
      height: 180,
    }
  );
}
