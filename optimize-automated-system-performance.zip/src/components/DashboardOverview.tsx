"use client";

import React from "react";
import { Zap, ShieldCheck, Cpu, Bot, TrendingUp, CheckCircle2, DollarSign, Clock, ArrowUpRight, Activity, AlertOctagon, PlayCircle } from "lucide-react";

interface DashboardOverviewProps {
  metrics: any;
  workflows: any[];
  executions: any[];
  incidents: any[];
  onNavigate: (tab: string) => void;
  onExecuteWorkflow: (wfId: string) => void;
  onTriggerBugScan: () => void;
  isExecuting: boolean;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  metrics,
  workflows,
  executions,
  incidents,
  onNavigate,
  onExecuteWorkflow,
  onTriggerBugScan,
  isExecuting,
}) => {
  const totalRuns = metrics.executions || executions.length || 720;
  const successCount = metrics.successfulExecutions || Math.floor(totalRuns * 0.998);
  const successRate = totalRuns > 0 ? ((successCount / totalRuns) * 100).toFixed(2) : "100.00";
  const hoursSaved = Math.floor(totalRuns * 0.25); // ~15 mins per manual execution
  const dollarsSaved = Math.floor(hoursSaved * 75); // $75/hour average engineering rate

  return (
    <div className="space-y-8 text-slate-100 pb-12">
      
      {/* Hero Banner Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 p-8 shadow-2xl">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f46e510_1px,transparent_1px),linear-gradient(to_bottom,#4f46e510_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
          <div className="lg:col-span-2 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-semibold border border-emerald-500/20">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Zero-Bug Architecture Verified • Autonomous Self-Healing Engine Active</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight bg-gradient-to-r from-white via-slate-200 to-indigo-200 bg-clip-text text-transparent">
              High-Speed Autonomous Workflow & Bug Deflector Engine
            </h1>
            <p className="text-slate-300 text-base max-w-2xl leading-relaxed">
              NexusAutomate AI replaces slow manual engineering tasks, database lock recoveries, and error triage with high-concurrency automated multi-step bots that detect, analyze, and cleanly remove system bugs in sub-second speed.
            </p>
            <div className="flex flex-wrap gap-4 pt-2">
              <button
                onClick={() => onNavigate("studio")}
                className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-[0_4px_20px_rgba(79,70,229,0.5)] transition flex items-center gap-2 border border-indigo-400"
              >
                <Zap className="w-4 h-4 text-cyan-300" />
                <span>Open Workflow Studio</span>
              </button>
              <button
                onClick={() => onNavigate("watchdog")}
                className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-sm transition flex items-center gap-2 border border-slate-700"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Test Bug Eliminator</span>
              </button>
            </div>
          </div>

          {/* Quick Real-Time Action Box */}
          <div className="bg-slate-900/90 rounded-2xl p-6 border border-indigo-500/30 shadow-inner">
            <h3 className="text-sm font-bold text-indigo-300 uppercase tracking-wider mb-4 flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span>Live System Diagnostic</span>
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                <span className="text-xs text-slate-400 font-medium">PostgreSQL Drizzle Pool:</span>
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded-md border border-emerald-800/50">Optimal • Zero Locks</span>
              </div>
              <div className="flex justify-between items-center bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                <span className="text-xs text-slate-400 font-medium">Autonomous Watchdog:</span>
                <span className="text-xs font-bold text-cyan-400 bg-cyan-950 px-2.5 py-1 rounded-md border border-cyan-800/50">Scanning 500 req/s</span>
              </div>
              <div className="flex justify-between items-center bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                <span className="text-xs text-slate-400 font-medium">Active Bug Count:</span>
                <span className="text-xs font-extrabold text-emerald-300 bg-emerald-900/40 px-2.5 py-1 rounded-md border border-emerald-500/50">0 Defects Found</span>
              </div>
            </div>
            <button
              onClick={onTriggerBugScan}
              className="w-full mt-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 font-extrabold text-xs text-white uppercase tracking-wider transition shadow-md flex items-center justify-center gap-2"
            >
              <Bot className="w-4 h-4" />
              <span>Trigger Simulated Auto-Heal Event</span>
            </button>
          </div>

        </div>
      </div>

      {/* KPI Key Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl shadow-xl hover:border-slate-700 transition">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 font-semibold text-sm">Automated Executions</span>
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Zap className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-white">{totalRuns.toLocaleString()}</div>
          <p className="text-xs text-indigo-400 font-medium mt-2 flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" /> +24% increased output this week
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl shadow-xl hover:border-slate-700 transition">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 font-semibold text-sm">Success Resolution Rate</span>
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-emerald-400">{successRate}%</div>
          <p className="text-xs text-slate-400 font-medium mt-2">
            Zero unresolved exceptions across pipelines
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl shadow-xl hover:border-slate-700 transition">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 font-semibold text-sm">Bugs Auto-Healed</span>
            <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-cyan-300">
            {metrics.autoHealedBugs || incidents.length || 5} <span className="text-sm font-bold text-slate-400">healed</span>
          </div>
          <p className="text-xs text-cyan-400 font-medium mt-2 flex items-center gap-1">
            Avg resolution speed: ~1.8 seconds
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl shadow-xl hover:border-slate-700 transition">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-400 font-semibold text-sm">Est. Automation Value</span>
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-amber-300">${dollarsSaved.toLocaleString()}</div>
          <p className="text-xs text-slate-400 font-medium mt-2 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-amber-400" /> {hoursSaved.toLocaleString()} eng hours saved
          </p>
        </div>
      </div>

      {/* Main Two Columns: Active Enterprise Workflows & Real-time Auto-Healing Events */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        
        {/* Active Workflows Quick Launcher */}
        <div className="lg:col-span-3 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Cpu className="w-5 h-5 text-indigo-400" />
                <span>Primary Automated Workflows</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">Click "Trigger Run" to test zero-bug real-time processing</p>
            </div>
            <button
              onClick={() => onNavigate("studio")}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1 bg-indigo-500/10 px-3 py-1.5 rounded-lg border border-indigo-500/20"
            >
              <span>View Studio</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {workflows && workflows.length > 0 ? (
              workflows.map((wf) => (
                <div
                  key={wf.id}
                  className="bg-slate-950/80 hover:bg-slate-900 transition rounded-xl p-4 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-base text-slate-100 group-hover:text-indigo-300 transition">
                        {wf.name}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-slate-800 text-slate-300 border border-slate-700">
                        {wf.category}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 line-clamp-1">{wf.description}</p>
                    <div className="flex items-center gap-4 text-[11px] text-slate-400 pt-1">
                      <span>Trigger: <strong className="text-slate-300 uppercase">{wf.triggerType}</strong></span>
                      <span>•</span>
                      <span>Runs: <strong className="text-emerald-400">{wf.executionCount || 0}</strong></span>
                      <span>•</span>
                      <span className="text-emerald-400 font-medium">100% Bug-Free</span>
                    </div>
                  </div>

                  <button
                    onClick={() => onExecuteWorkflow(wf.id)}
                    disabled={isExecuting}
                    className="px-4 py-2 bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 rounded-xl font-semibold text-xs whitespace-nowrap transition duration-200 flex items-center justify-center gap-1.5 group-hover:border-indigo-500 shadow"
                  >
                    <PlayCircle className="w-4 h-4 text-cyan-400" />
                    <span>Trigger Run</span>
                  </button>
                </div>
              ))
            ) : (
              <p className="text-sm text-slate-500 italic py-4">No active workflows loaded yet.</p>
            )}
          </div>
        </div>

        {/* Live Auto-Healed Watchdog Feed */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-lg font-extrabold text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <span>Autonomous Bug Remediation</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">Live anomalies detected and cleanly healed</p>
            </div>
            <button
              onClick={() => onNavigate("watchdog")}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-bold bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/20"
            >
              <span>Details</span>
            </button>
          </div>

          <div className="space-y-4">
            {incidents && incidents.length > 0 ? (
              incidents.slice(0, 4).map((inc) => (
                <div key={inc.id} className="bg-slate-950/90 rounded-xl p-4 border border-slate-800/80 hover:border-slate-700 transition">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                      Auto-Healed in {inc.resolutionTimeSec}s
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {inc.service}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-200 mb-1">{inc.title}</h4>
                  <p className="text-[11px] text-cyan-300/80 font-medium line-clamp-2 bg-cyan-950/20 p-2 rounded-lg border border-cyan-800/30">
                    💡 <strong>Fix applied:</strong> {inc.automatedAction}
                  </p>
                </div>
              ))
            ) : (
              <p className="text-sm text-slate-500 italic py-4">No recent system incident detections.</p>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
