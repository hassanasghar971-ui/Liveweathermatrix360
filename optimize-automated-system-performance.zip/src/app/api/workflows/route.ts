import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { workflows, workflowNodes } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { seedInitialData } from "@/lib/seed";

export async function GET() {
  try {
    await seedInitialData(); // ensure seeded
    
    const allWorkflows = await db.select().from(workflows).orderBy(desc(workflows.updatedAt));
    const allNodes = await db.select().from(workflowNodes).orderBy(workflowNodes.stepOrder);

    // Attach nodes to their respective workflow
    const enrichedWorkflows = allWorkflows.map(wf => ({
      ...wf,
      triggerConfig: (() => { try { return JSON.parse(wf.triggerConfig); } catch { return {}; } })(),
      nodes: allNodes
        .filter(n => n.workflowId === wf.id)
        .map(n => ({
          ...n,
          config: (() => { try { return JSON.parse(n.config); } catch { return {}; } })()
        }))
    }));

    return NextResponse.json({ workflows: enrichedWorkflows });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, description, category, triggerType, triggerConfig, nodes } = body;

    if (!name || !description || !category || !triggerType) {
      return NextResponse.json({ error: "Missing required workflow parameters" }, { status: 400 });
    }

    const workflowId = `wf-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const newWf = {
      id: workflowId,
      name,
      description,
      category,
      status: "active",
      triggerType,
      triggerConfig: JSON.stringify(triggerConfig || { endpoint: `/api/webhook/${workflowId}` }),
      executionCount: 0,
      successCount: 0,
      lastRunAt: new Date(),
      createdAt: new Date(),
      updatedAt: new Date()
    };

    await db.insert(workflows).values(newWf);

    // Insert nodes if provided, else insert a default start & end action
    if (Array.isArray(nodes) && nodes.length > 0) {
      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i];
        await db.insert(workflowNodes).values({
          id: `node-${Date.now().toString(36)}-${i}`,
          workflowId,
          label: n.label || `Step ${i + 1}`,
          nodeType: n.nodeType || "action",
          actionType: n.actionType || "REST API / Automated Processing",
          config: JSON.stringify(n.config || { automated: true }),
          stepOrder: i + 1,
        });
      }
    } else {
      // default nodes
      await db.insert(workflowNodes).values({
        id: `node-${Date.now().toString(36)}-1`,
        workflowId,
        label: `${triggerType.toUpperCase()} Trigger Event`,
        nodeType: "trigger",
        actionType: "Event Listener",
        config: JSON.stringify({ automated: true }),
        stepOrder: 1,
      });
      await db.insert(workflowNodes).values({
        id: `node-${Date.now().toString(36)}-2`,
        workflowId,
        label: "AI Diagnostic & Action Executor",
        nodeType: "ai",
        actionType: "Automated Data Processing",
        config: JSON.stringify({ validation: "Zero-Bug Guarantee", confidence: "99.9%" }),
        stepOrder: 2,
      });
    }

    return NextResponse.json({ success: true, workflowId, message: "Workflow created successfully" });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
