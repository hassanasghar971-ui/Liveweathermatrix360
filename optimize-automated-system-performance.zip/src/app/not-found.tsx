"use client";

import React from "react";
import Link from "next/link";
import { CloudLightning, ShieldCheck, Home, FolderOpen, Radio } from "lucide-react";
import { WeatherMatrixFloatingFolder } from "@/components/WeatherMatrixFloatingFolder";

export default function NotFoundPage() {
  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6 text-center relative selection:bg-cyan-500">
      <div className="max-w-xl w-full bg-slate-900/95 border-2 border-cyan-500/60 rounded-3xl p-8 shadow-[0_0_80px_rgba(6,182,212,0.35)] space-y-6 z-10">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 via-sky-600 to-indigo-600 flex items-center justify-center mx-auto shadow-lg border border-cyan-300/40 animate-pulse">
          <CloudLightning className="w-9 h-9 text-white" />
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-black uppercase tracking-wider">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>404 Error Neutralized • WeatherMatrix Folder Docked</span>
          </div>
          <h1 className="text-2xl md:text-4xl font-black text-white">
            Live WeatherMatrix Command Grid
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed font-medium">
            Your requested endpoint or shortcut has been caught by our Autonomous Route Shield! Zero functionality is lost—your Live WeatherMatrix floating folder and automated storm deflector are pinned to your screen below.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
          <Link
            href="/"
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-cyan-500 via-sky-600 to-indigo-600 hover:opacity-95 text-white font-extrabold text-sm uppercase tracking-wider shadow-[0_0_25px_rgba(6,182,212,0.45)] transition flex items-center justify-center gap-2 border border-cyan-300/50"
          >
            <Home className="w-4 h-4" />
            <span>Open Master Hub</span>
          </Link>

          <Link
            href="/weathermatrix"
            className="w-full py-3.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-extrabold text-sm transition flex items-center justify-center gap-2 border border-slate-700 hover:border-cyan-500/50"
          >
            <FolderOpen className="w-4 h-4 text-emerald-400" />
            <span>Live WeatherMatrix →</span>
          </Link>
        </div>

        <div className="pt-4 border-t border-slate-800/80 text-xs text-emerald-400 font-bold flex items-center justify-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Universal Fallback Active • Click floating folder at bottom-right</span>
        </div>
      </div>

      {/* Keep the floating docked screen widget active even here! */}
      <WeatherMatrixFloatingFolder
        onNavigate={(tab) => {
          if (typeof window !== "undefined") window.location.href = `/?tab=${tab}`;
        }}
        onTriggerBugScan={async () => {
          try {
            await fetch("/api/incidents/auto-heal", { method: "POST", body: JSON.stringify({ type: "watchdog_scan" }) });
            alert("✅ Autonomous self-healing complete! All 404 anomalies eliminated.");
          } catch (e) {
            console.error(e);
          }
        }}
      />
    </main>
  );
}
