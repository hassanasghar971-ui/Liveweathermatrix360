import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    name: "Live WeatherMatrix AI & Autonomous Engine",
    short_name: "WeatherMatrix",
    description: "Permanently docked Live WeatherMatrix radar, storm front prediction, and automated zero-bug workflow system.",
    start_url: "/",
    display: "standalone",
    background_color: "#020617",
    theme_color: "#06b6d4",
    icons: [
      { src: "/favicon.ico", sizes: "64x64 32x32 24x24 16x16", type: "image/x-icon" },
      { src: "/icon", sizes: "192x192", type: "image/png" },
      { src: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
      { src: "/logo.png", sizes: "512x512", type: "image/png" }
    ],
  }, {
    status: 200,
    headers: {
      "Content-Type": "application/manifest+json",
      "Cache-Control": "public, max-age=3600",
    },
  });
}
