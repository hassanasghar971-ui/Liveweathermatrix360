import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { automationSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { seedInitialData } from "@/lib/seed";

export async function GET() {
  try {
    await seedInitialData();
    const settings = await db.select().from(automationSettings);
    return NextResponse.json({ settings });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { key, value } = body;
    if (!key || value === undefined) {
      return NextResponse.json({ error: "Key and value are required" }, { status: 400 });
    }

    await db.update(automationSettings).set({ value, updatedAt: new Date() }).where(eq(automationSettings.key, key));

    return NextResponse.json({ success: true, message: "Setting updated successfully" });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
