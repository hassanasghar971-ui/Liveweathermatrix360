import { ImageResponse } from "next/og";
import React from "react";

export const runtime = "edge";

export async function GET() {
  return new ImageResponse(
    React.createElement(
      "div",
      {
        style: {
          fontSize: 320,
          background: "linear-gradient(135deg, #0284c7, #4f46e5)",
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "#ffffff",
          borderRadius: 90,
          fontWeight: 900,
          border: "16px solid #e0f2fe",
          boxShadow: "0 20px 60px rgba(14, 165, 233, 0.4)",
        },
      },
      "⚡"
    ),
    {
      width: 512,
      height: 512,
    }
  );
}
