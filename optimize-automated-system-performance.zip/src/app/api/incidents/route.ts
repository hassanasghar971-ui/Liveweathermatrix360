import { NextResponse } from "next/server";
import { db } from "@/db";
import { systemIncidents } from "@/db/schema";
import { desc } from "drizzle-orm";
import { seedInitialData } from "@/lib/seed";

export async function GET() {
  try {
    await seedInitialData();
    const incidents = await db.select().from(systemIncidents).orderBy(desc(systemIncidents.timestamp));
    return NextResponse.json({ incidents });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
