import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";

export const workflows = pgTable("workflows", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // DevOps & SRE, Security, AI & Data, Finance & Commerce, Customer Support
  status: text("status").notNull().default("active"), // active, paused, draft
  triggerType: text("trigger_type").notNull(), // schedule, webhook, error_alert, threshold, ai_agent
  triggerConfig: text("trigger_config").notNull(), // JSON string representing scheduling or endpoint data
  executionCount: integer("execution_count").notNull().default(0),
  successCount: integer("success_count").notNull().default(0),
  lastRunAt: timestamp("last_run_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const workflowNodes = pgTable("workflow_nodes", {
  id: text("id").primaryKey(),
  workflowId: text("workflow_id")
    .references(() => workflows.id, { onDelete: "cascade" })
    .notNull(),
  label: text("label").notNull(),
  nodeType: text("node_type").notNull(), // trigger, action, condition, ai, webhook, notification, auto_heal
  actionType: text("action_type").notNull(), // e.g., "HTTP Request", "AI Sentiment", "DB Query", "Slack Broadcast", "Restart Pod"
  config: text("config").notNull(), // JSON string configuration parameters
  stepOrder: integer("step_order").notNull(),
});

export const executions = pgTable("executions", {
  id: text("id").primaryKey(),
  workflowId: text("workflow_id")
    .references(() => workflows.id, { onDelete: "cascade" })
    .notNull(),
  workflowName: text("workflow_name").notNull(),
  status: text("status").notNull(), // completed, failed, running, retrying, healed
  triggerSource: text("trigger_source").notNull(), // Manual Test, Scheduled Cron, Webhook Event, Watchdog Alert, AI Agent Trigger
  durationMs: integer("duration_ms").notNull(),
  logs: text("logs").notNull(), // JSON string array of execution steps and diagnostics
  outputPayload: text("output_payload").notNull(), // JSON output data or remediation response
  errorDetails: text("error_details"), // Details if incident occurred or was resolved
  executedAt: timestamp("executed_at").defaultNow(),
});

export const systemIncidents = pgTable("system_incidents", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  service: text("service").notNull(), // e.g. PostgreSQL Pool, Auth Microservice, Redis Cache Layer, Worker Queue, Stripe Gateway
  severity: text("severity").notNull(), // critical, high, medium, low
  status: text("status").notNull(), // auto_healed, detecting, remedying, manual_required
  symptom: text("symptom").notNull(),
  automatedAction: text("automated_action").notNull(), // Remediation performed automatically
  resolutionTimeSec: integer("resolution_time_sec").notNull(),
  confidenceScore: integer("confidence_score").notNull(), // % success confidence
  timestamp: timestamp("timestamp").defaultNow(),
});

export const automationSettings = pgTable("automation_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  description: text("description").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});
