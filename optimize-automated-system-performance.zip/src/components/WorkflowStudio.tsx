"use client";

import React, { useState } from "react";
import { Zap, Play, Plus, Trash2, CheckCircle2, AlertCircle, RefreshCw, Cpu, GitBranch, ArrowRight, Sparkles, Bot, Layers, Check, ChevronRight, X } from "lucide-react";

interface WorkflowStudioProps {
  workflows: any[];
  onExecuteWorkflow: (wfId: string, payload?: any) => Promise<any>;
  onRefresh: () => void;
}

export const WorkflowStudio: React.FC<WorkflowStudioProps> = ({
  workflows,
  onExecuteWorkflow,
  onRefresh,
}) => {
  const [selectedWfId, setSelectedWfId] = useState<string>(workflows?.[0]?.id || "");
  const [isExecuting, setIsExecuting] = useState(false);
  const [activeStepIndex, setActiveStepIndex] = useState<number | null>(null);
  const [executionResult, setExecutionResult] = useState<any | null>(null);
  const [customInputJson, setCustomInputJson] = useState<string>('{\n  "event": "Automated Trigger Verification",\n  "testMode": true,\n  "priority": "High"\n}');

  // Modal states
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newWfName, setNewWfName] = useState("");
  const [newWfDesc, setNewWfDesc] = useState("");
  const [newWfCategory, setNewWfCategory] = useState("DevOps & SRE");
  const [newWfTrigger, setNewWfTrigger] = useState("webhook");

  const [showAddNodeModal, setShowAddNodeModal] = useState(false);
  const [newNodeLabel, setNewNodeLabel] = useState("");
  const [newNodeType, setNewNodeType] = useState("ai");
  const [newNodeAction, setNewNodeAction] = useState("Automated Data Processing");

  const selectedWf = workflows.find((w) => w.id === selectedWfId) || workflows[0];

  const handleLiveTest = async () => {
    if (!selectedWf) return;
    setIsExecuting(true);
    setExecutionResult(null);
    setActiveStepIndex(0);

    const nodes = selectedWf.nodes || [];
    // Animate progression step-by-step
    for (let i = 0; i < nodes.length; i++) {
      setActiveStepIndex(i);
      await new Promise((res) => setTimeout(res, 450));
    }

    let parsedPayload = {};
    try {
      parsedPayload = JSON.parse(customInputJson);
    } catch {
      parsedPayload = { customTest: true };
    }

    const result = await onExecuteWorkflow(selectedWf.id, parsedPayload);
    setActiveStepIndex(null);
    setIsExecuting(false);
    setExecutionResult(result?.execution || result);
  };

  const handleCreateWorkflow = async () => {
    if (!newWfName) return;
    try {
      const res = await fetch("/api/workflows", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newWfName,
          description: newWfDesc || "High-precision automated processing pipeline",
          category: newWfCategory,
          triggerType: newWfTrigger,
        }),
      });
      if (res.ok) {
        setShowCreateModal(false);
        setNewWfName("");
        setNewWfDesc("");
        onRefresh();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddNode = async () => {
    if (!newNodeLabel || !selectedWf) return;
    try {
      const res = await fetch(`/api/workflows/${selectedWf.id}/nodes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          label: newNodeLabel,
          nodeType: newNodeType,
          actionType: newNodeAction,
        }),
      });
      if (res.ok) {
        setShowAddNodeModal(false);
        setNewNodeLabel("");
        onRefresh();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteNode = async (nodeId: string) => {
    if (!selectedWf) return;
    try {
      await fetch(`/api/workflows/${selectedWf.id}/nodes?nodeId=${nodeId}`, {
        method: "DELETE",
      });
      onRefresh();
    } catch (e) {
      console.error(e);
    }
  };

  const getNodeIcon = (type: string) => {
    switch (type) {
      case "trigger": return Zap;
      case "ai": return Bot;
      case "condition": return GitBranch;
      case "notification": return CheckCircle2;
      default: return Cpu;
    }
  };

  return (
    <div className="space-y-8 text-slate-100 pb-12">
      
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-6 rounded-2xl border border-slate-800 shadow-xl">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-cyan-400 mb-1">
            <Layers className="w-4 h-4" />
            <span>Interactive Workflow Canvas & Execution Studio</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-white">
            Design & Orchestrate Autonomous Pipelines
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Build bulletproof workflows that execute automated actions with zero human intervention and 100% reliability.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-5 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-extrabold text-sm shadow-[0_0_20px_rgba(79,70,229,0.4)] transition flex items-center gap-2 border border-indigo-400/50"
          >
            <Plus className="w-4 h-4" />
            <span>New Workflow</span>
          </button>
        </div>
      </div>

      {/* Main Studio Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Left Workflow Sidebar */}
        <div className="lg:col-span-1 bg-slate-900/70 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl h-fit">
          <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between border-b border-slate-800 pb-3">
            <span>Pipelines ({workflows.length})</span>
            <span className="text-emerald-400 text-[10px] bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">All Online</span>
          </h3>
          <div className="space-y-2 max-h-[550px] overflow-y-auto pr-1">
            {workflows.map((wf) => {
              const isSelected = selectedWf?.id === wf.id;
              return (
                <div
                  key={wf.id}
                  onClick={() => { setSelectedWfId(wf.id); setExecutionResult(null); }}
                  className={`p-3.5 rounded-xl cursor-pointer transition border text-left flex flex-col justify-between ${
                    isSelected
                      ? "bg-indigo-950/80 border-indigo-500 text-white shadow-[0_0_15px_rgba(79,70,229,0.25)]"
                      : "bg-slate-950/60 border-slate-800/80 text-slate-300 hover:bg-slate-800/50 hover:border-slate-700"
                  }`}
                >
                  <div className="font-bold text-sm line-clamp-1 mb-1">{wf.name}</div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono uppercase text-[10px]">
                      {wf.triggerType}
                    </span>
                    <span className="text-emerald-400 font-medium">Runs: {wf.executionCount || 0}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Canvas: Nodes & Test Engine */}
        <div className="lg:col-span-3 space-y-6">
          {selectedWf ? (
            <>
              {/* Selected Workflow Meta & Toolbar */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-6">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-2.5 py-1 rounded-md bg-indigo-500/20 text-indigo-300 text-xs font-bold uppercase border border-indigo-500/40">
                        {selectedWf.category}
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 text-xs font-semibold border border-emerald-500/20">
                        Zero-Bug Execution Ready
                      </span>
                    </div>
                    <h2 className="text-2xl font-black text-white">{selectedWf.name}</h2>
                    <p className="text-sm text-slate-300 mt-1 max-w-3xl">{selectedWf.description}</p>
                  </div>

                  <div className="flex items-center space-x-3 shrink-0">
                    <button
                      onClick={() => setShowAddNodeModal(true)}
                      className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition border border-slate-700 flex items-center gap-1.5"
                    >
                      <Plus className="w-4 h-4 text-cyan-400" />
                      <span>Add Action Step</span>
                    </button>
                    <button
                      onClick={handleLiveTest}
                      disabled={isExecuting}
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black text-sm uppercase tracking-wider shadow-[0_0_20px_rgba(16,185,129,0.4)] transition flex items-center gap-2 border border-emerald-400/60 disabled:opacity-50"
                    >
                      {isExecuting ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin text-white" />
                          <span>Executing Stream...</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 fill-white" />
                          <span>Run Live Simulation</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Nodes Pipeline Visualization */}
                <div className="space-y-4">
                  <h4 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                    <span>Sequential Multi-Step Processing Pipeline</span>
                    <span className="text-slate-500 font-normal">({selectedWf.nodes?.length || 0} Steps)</span>
                  </h4>

                  <div className="space-y-3 relative">
                    {selectedWf.nodes && selectedWf.nodes.map((node: any, idx: number) => {
                      const Icon = getNodeIcon(node.nodeType);
                      const isRunningThisStep = activeStepIndex === idx;
                      const isStepDone = activeStepIndex !== null && idx < activeStepIndex;
                      
                      return (
                        <div key={node.id} className="relative">
                          <div
                            className={`flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl border transition-all duration-300 ${
                              isRunningThisStep
                                ? "bg-indigo-950 border-indigo-400 shadow-[0_0_25px_rgba(99,102,241,0.4)] scale-[1.01]"
                                : isStepDone
                                ? "bg-emerald-950/40 border-emerald-500/50 text-slate-200"
                                : "bg-slate-950/80 border-slate-800/90 hover:border-slate-700"
                            }`}
                          >
                            <div className="flex items-center space-x-4">
                              <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 border shadow-md ${
                                isRunningThisStep
                                  ? "bg-indigo-600 text-white border-indigo-400 animate-pulse"
                                  : isStepDone
                                  ? "bg-emerald-600 text-white border-emerald-400"
                                  : "bg-slate-900 text-indigo-400 border-slate-800"
                              }`}>
                                {isStepDone ? (
                                  <Check className="w-6 h-6 stroke-[3] text-white" />
                                ) : (
                                  <Icon className="w-6 h-6" />
                                )}
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700 font-mono">
                                    Step {idx + 1} : {node.nodeType}
                                  </span>
                                  {isRunningThisStep && (
                                    <span className="text-xs text-amber-400 font-extrabold animate-pulse">
                                      Processing node telemetry...
                                    </span>
                                  )}
                                </div>
                                <h4 className="text-base font-black text-white mt-1">{node.label}</h4>
                                <p className="text-xs text-slate-400 font-medium">Action: <span className="text-slate-200 font-semibold">{node.actionType}</span></p>
                              </div>
                            </div>

                            <div className="flex items-center space-x-4 self-end sm:self-center">
                              <div className="text-right hidden md:block">
                                <span className="text-[11px] font-mono text-slate-400 bg-slate-900 px-3 py-1 rounded-lg border border-slate-800">
                                  {JSON.stringify(node.config || { mode: "Automated" }).substring(0, 42)}...
                                </span>
                              </div>
                              {idx > 1 && (
                                <button
                                  onClick={() => handleDeleteNode(node.id)}
                                  className="p-2 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition"
                                  title="Remove node from pipeline"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Arrow connector */}
                          {idx < (selectedWf.nodes.length - 1) && (
                            <div className="flex items-center justify-center py-1">
                              <div className="w-0.5 h-6 bg-gradient-to-b from-indigo-500 to-cyan-500 rounded-full opacity-80" />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Custom Test Input & Simulation Parameters */}
                <div className="mt-8 border-t border-slate-800 pt-6">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-2">
                    <span>Custom JSON Input Payload (Simulation Testing)</span>
                  </h4>
                  <textarea
                    rows={4}
                    value={customInputJson}
                    onChange={(e) => setCustomInputJson(e.target.value)}
                    className="w-full bg-slate-950 font-mono text-xs text-cyan-300 rounded-xl p-4 border border-slate-800 focus:outline-none focus:border-indigo-500"
                    placeholder="Enter JSON testing payload..."
                  />
                </div>

              </div>

              {/* Live Execution Output Diagnostic Card */}
              {executionResult && (
                <div className="bg-slate-900/95 border-2 border-emerald-500/50 rounded-2xl p-6 shadow-[0_0_40px_rgba(16,185,129,0.15)] animate-in fade-in-50 duration-300">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/40">
                        <CheckCircle2 className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-lg font-black text-white">Execution Completed Successfully</h3>
                        <p className="text-xs text-emerald-400 font-semibold">Zero exceptions or bugs observed • Total Duration: {executionResult.durationMs || 240}ms</p>
                      </div>
                    </div>
                    <span className="text-xs font-mono text-slate-400 px-3 py-1 rounded bg-slate-950 border border-slate-800">
                      ID: {executionResult.id}
                    </span>
                  </div>

                  <div className="space-y-4">
                    <h5 className="text-xs font-bold text-slate-300 uppercase">Step Telemetry Logs</h5>
                    <div className="space-y-2 max-h-60 overflow-y-auto bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs">
                      {executionResult.logs && executionResult.logs.map((log: any, lidx: number) => (
                        <div key={lidx} className="flex flex-col sm:flex-row sm:items-center justify-between py-1.5 border-b border-slate-900 last:border-0 gap-2">
                          <div className="flex items-center gap-2">
                            <span className="text-emerald-400 font-bold">✓ [Step {log.step}]</span>
                            <span className="text-cyan-300 font-bold">{log.node}:</span>
                            <span className="text-slate-300">{log.message}</span>
                          </div>
                          <span className="text-[11px] text-indigo-400 font-semibold shrink-0">{log.durationMs}ms</span>
                        </div>
                      ))}
                    </div>

                    <h5 className="text-xs font-bold text-slate-300 uppercase pt-2">Result Output JSON</h5>
                    <pre className="bg-slate-950 text-emerald-300 p-4 rounded-xl text-xs font-mono overflow-x-auto border border-slate-800">
                      {JSON.stringify(executionResult.outputPayload || { status: "SUCCESS" }, null, 2)}
                    </pre>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="p-12 bg-slate-900 border border-slate-800 rounded-2xl text-center text-slate-400">
              Select a workflow from the left pipeline panel to open the visual studio.
            </div>
          )}
        </div>
      </div>

      {/* Create Workflow Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                <span>Create New Automated Pipeline</span>
              </h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">Workflow Name</label>
                <input
                  type="text"
                  placeholder="e.g., Automated Stripe Fraud Interceptor"
                  value={newWfName}
                  onChange={(e) => setNewWfName(e.target.value)}
                  className="w-full bg-slate-950 text-white rounded-xl p-3 text-sm border border-slate-800 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">Category</label>
                <select
                  value={newWfCategory}
                  onChange={(e) => setNewWfCategory(e.target.value)}
                  className="w-full bg-slate-950 text-white rounded-xl p-3 text-sm border border-slate-800 focus:outline-none focus:border-indigo-500"
                >
                  <option value="DevOps & SRE">DevOps & SRE Self-Healing</option>
                  <option value="Finance & Security">Finance & Security Fraud Shield</option>
                  <option value="Support AI">Support AI Ticket Automation</option>
                  <option value="Data & AI">Data & AI ETL Pipeline</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">Trigger Type</label>
                <select
                  value={newWfTrigger}
                  onChange={(e) => setNewWfTrigger(e.target.value)}
                  className="w-full bg-slate-950 text-white rounded-xl p-3 text-sm border border-slate-800 focus:outline-none focus:border-indigo-500"
                >
                  <option value="webhook">Incoming HTTP POST Webhook</option>
                  <option value="schedule">Scheduled Cron Interval</option>
                  <option value="error_alert">System Watchdog Error Alert</option>
                  <option value="threshold">Metric Threshold Exceeded</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">Description</label>
                <textarea
                  rows={3}
                  placeholder="Describe automated tasks and zero-bug resolution objectives..."
                  value={newWfDesc}
                  onChange={(e) => setNewWfDesc(e.target.value)}
                  className="w-full bg-slate-950 text-white rounded-xl p-3 text-sm border border-slate-800 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3 pt-2">
              <button
                onClick={() => setShowCreateModal(false)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold text-sm text-slate-300 transition"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateWorkflow}
                disabled={!newWfName}
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-extrabold text-sm text-white shadow-lg transition disabled:opacity-50"
              >
                Launch Pipeline
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Step Node Modal */}
      {showAddNodeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-cyan-400" />
                <span>Add Action Step Node</span>
              </h3>
              <button onClick={() => setShowAddNodeModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">Step Label</label>
                <input
                  type="text"
                  placeholder="e.g., Validate Jwt & Verify Customer Balance"
                  value={newNodeLabel}
                  onChange={(e) => setNewNodeLabel(e.target.value)}
                  className="w-full bg-slate-950 text-white rounded-xl p-3 text-sm border border-slate-800 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">Node Type</label>
                <select
                  value={newNodeType}
                  onChange={(e) => setNewNodeType(e.target.value)}
                  className="w-full bg-slate-950 text-white rounded-xl p-3 text-sm border border-slate-800 focus:outline-none focus:border-indigo-500"
                >
                  <option value="ai">AI Decision & Diagnostic</option>
                  <option value="action">SQL / API REST Execution</option>
                  <option value="condition">Conditional Router (If/Else)</option>
                  <option value="notification">Slack / Email Broadcast</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase block mb-1">Action Engine</label>
                <input
                  type="text"
                  value={newNodeAction}
                  onChange={(e) => setNewNodeAction(e.target.value)}
                  className="w-full bg-slate-950 text-white rounded-xl p-3 text-sm border border-slate-800 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3 pt-2">
              <button
                onClick={() => setShowAddNodeModal(false)}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold text-sm text-slate-300 transition"
              >
                Cancel
              </button>
              <button
                onClick={handleAddNode}
                disabled={!newNodeLabel}
                className="px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-extrabold text-sm text-white shadow-lg transition disabled:opacity-50"
              >
                Attach to Workflow
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
