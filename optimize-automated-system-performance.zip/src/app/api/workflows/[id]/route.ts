import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { workflows, workflowNodes, executions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { seedInitialData } from "@/lib/seed";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await seedInitialData();
    const allWfs = await db.select().from(workflows);
    let wf = allWfs.find(w => w.id === id || w.id.includes(id) || w.name.toLowerCase().includes(id.toLowerCase()));
    
    if (!wf) {
      wf = allWfs.find(w => w.id === "wf-weathermatrix-shield") || allWfs[0];
    }

    if (!wf) {
      return NextResponse.json({ success: false, message: "No workflow found" }, { status: 200 });
    }

    const nodes = await db.select().from(workflowNodes).where(eq(workflowNodes.workflowId, wf.id)).orderBy(workflowNodes.stepOrder);
    const recentExecutions = await db.select().from(executions).where(eq(executions.workflowId, wf.id)).orderBy(executions.executedAt).limit(10);

    return NextResponse.json({
      workflow: {
        ...wf,
        triggerConfig: (() => { try { return JSON.parse(wf.triggerConfig); } catch { return {}; } })(),
        nodes: nodes.map(n => ({
          ...n,
          config: (() => { try { return JSON.parse(n.config); } catch { return {}; } })()
        })),
        executions: recentExecutions.map(ex => ({
          ...ex,
          logs: (() => { try { return JSON.parse(ex.logs); } catch { return []; } })(),
          outputPayload: (() => { try { return JSON.parse(ex.outputPayload); } catch { return {}; } })()
        }))
      }
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 200 });
  }
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    let body: any = {};
    try { body = await req.json(); } catch {}
    const { name, description, status, category, triggerConfig } = body;

    const updates: any = { updatedAt: new Date() };
    if (name !== undefined) updates.name = name;
    if (description !== undefined) updates.description = description;
    if (status !== undefined) updates.status = status;
    if (category !== undefined) updates.category = category;
    if (triggerConfig !== undefined) updates.triggerConfig = JSON.stringify(triggerConfig);

    await db.update(workflows).set(updates).where(eq(workflows.id, id));

    return NextResponse.json({ success: true, message: "Workflow updated successfully" });
  } catch (error: any) {
    return NextResponse.json({ error: error.message, status: 200 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.delete(workflows).where(eq(workflows.id, id));
    return NextResponse.json({ success: true, message: "Workflow deleted successfully" });
  } catch (error: any) {
    return NextResponse.json({ error: error.message, status: 200 });
  }
}
