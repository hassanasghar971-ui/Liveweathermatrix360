"use client";
import Metrics360Page from "@/app/metrics360/page";
export default function BlogAliasPage() {
  return <Metrics360Page />;
}
